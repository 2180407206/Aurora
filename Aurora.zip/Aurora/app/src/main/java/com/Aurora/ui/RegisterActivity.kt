package com.Aurora.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.LoginReq
import com.Aurora.model.RegisterReq
import com.Aurora.util.ErrUtil
import com.Aurora.util.TokenManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class RegisterActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etU = findViewById<EditText>(R.id.etUsername)
        val etE = findViewById<EditText>(R.id.etEmail)
        val etP = findViewById<EditText>(R.id.etPassword)
        val btnReg = findViewById<Button>(R.id.btnRegister)
        val tvBack = findViewById<TextView>(R.id.tvBack)

        btnReg.setOnClickListener {
            val u = etU.text.toString().trim()
            val e = etE.text.toString().trim().ifEmpty { null }
            val p = etP.text.toString()
            if (u.length < 3 || p.length < 6) {
                Toast.makeText(this, "用户名≥3位，密码≥6位", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            btnReg.isEnabled = false
            mainScope.launch {
                try {
                    ApiClient.get(this@RegisterActivity).register(RegisterReq(u, p, e))
                    Toast.makeText(this@RegisterActivity, "注册成功，正在登录...", Toast.LENGTH_SHORT).show()
                    // 自动登录
                    val resp = ApiClient.get(this@RegisterActivity).login(LoginReq(u, p))
                    TokenManager.saveToken(this@RegisterActivity, resp.accessToken)
                    finish()
                } catch (t: Throwable) {
                    Toast.makeText(this@RegisterActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                } finally {
                    btnReg.isEnabled = true
                }
            }
        }

        tvBack.setOnClickListener { finish() }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}