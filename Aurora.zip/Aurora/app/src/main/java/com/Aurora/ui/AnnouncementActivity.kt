package com.Aurora.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.Announcement
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import android.os.Bundle

class AnnouncementActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var adapter: AnnAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_announcement)

        val swipe = findViewById<SwipeRefreshLayout>(R.id.swipeAnn)
        val rv = findViewById<RecyclerView>(R.id.rvAnnouncement)
        adapter = AnnAdapter { ann -> markRead(ann) }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        swipe.setOnRefreshListener { load { swipe.isRefreshing = false } }
        findViewById<View>(R.id.btnReadAll).setOnClickListener {
            mainScope.launch {
                try {
                    ApiClient.get(this@AnnouncementActivity).markAllRead()
                    load {}
                } catch (t: Throwable) {
                    Toast.makeText(this@AnnouncementActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                }
            }
        }
        load {}
    }

    private fun load(done: () -> Unit) {
        mainScope.launch {
            try {
                val r = ApiClient.get(this@AnnouncementActivity).announcements(50)
                adapter.update(r.items)
            } catch (t: Throwable) {
                Toast.makeText(this@AnnouncementActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            } finally {
                done()
            }
        }
    }

    private fun markRead(a: Announcement) {
        if (a.isRead) return
        mainScope.launch {
            try {
                ApiClient.get(this@AnnouncementActivity).markRead(a.id)
                load {}
            } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}

class AnnAdapter(
    private var data: List<Announcement>,
    private val onClick: (Announcement) -> Unit
) : RecyclerView.Adapter<AnnAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvLevel: TextView = v.findViewById(R.id.tvLevel)
        val tvTitle: TextView = v.findViewById(R.id.tvTitle)
        val tvContent: TextView = v.findViewById(R.id.tvContent)
        val tvTime: TextView = v.findViewById(R.id.tvTime)
        val tvUnread: TextView = v.findViewById(R.id.tvUnread)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_announcement, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val a = data[pos]
        h.tvLevel.text = a.level
        h.tvLevel.setBackgroundColor(when (a.level) {
            "warning" -> 0xFFF9A825.toInt()
            "error" -> 0xFFE53935.toInt()
            "success" -> 0xFF43A047.toInt()
            else -> 0xFF1E88E5.toInt()
        })
        h.tvTitle.text = a.title
        h.tvContent.text = a.content
        h.tvTime.text = a.publishAt ?: ""
        h.tvUnread.visibility = if (a.isRead) View.GONE else View.VISIBLE
        h.itemView.setOnClickListener { onClick(a) }
    }

    override fun getItemCount() = data.size

    fun update(n: List<Announcement>) { data = n; notifyDataSetChanged() }
}