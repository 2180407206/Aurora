package com.Aurora.realtime

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * 轻量 SSE 客户端（无第三方依赖）。
 * 特点：
 *   - 独立守护线程，逐行读取 text/event-stream
 *   - 断线自动重连，指数退避（1s → 30s 封顶）
 *   - 事件回调统一切到主线程
 *   - 关闭时取消底层 Call，避免线程悬挂
 */
class SseClient(
    private val url: String,
    private val token: String?,
    private val listener: Listener
) {
    interface Listener {
        fun onOpen()
        fun onEvent(data: String)
        fun onError(t: Throwable?)
    }

    @Volatile private var closed = false
    @Volatile private var currentCall: okhttp3.Call? = null
    private var thread: Thread? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)          // SSE 不能有读超时
        .retryOnConnectionFailure(true)
        .build()

    fun start() {
        if (thread != null) return
        closed = false
        thread = Thread({ loop() }, "sse-${url.hashCode()}").apply {
            isDaemon = true
            start()
        }
    }

    fun close() {
        closed = true
        try { currentCall?.cancel() } catch (_: Exception) {}
        thread?.interrupt()
        thread = null
    }

    private fun loop() {
        var retryDelay = 1000L
        while (!closed && !Thread.currentThread().isInterrupted) {
            try {
                doRequest()
                // 服务端正常关闭连接，重置退避
                retryDelay = 1000L
            } catch (t: Throwable) {
                if (closed) return
                post { listener.onError(t) }
            }
            if (closed) return
            try {
                Thread.sleep(retryDelay)
            } catch (_: InterruptedException) {
                return
            }
            retryDelay = (retryDelay * 2).coerceAtMost(30_000L)
        }
    }

    private fun doRequest() {
        val builder = Request.Builder()
            .url(url)
            .header("Accept", "text/event-stream")
            .header("Cache-Control", "no-cache")
            .header("Connection", "keep-alive")
        if (!token.isNullOrBlank()) {
            builder.header("Authorization", "Bearer $token")
        }
        val req = builder.build()

        val call = client.newCall(req)
        currentCall = call

        call.execute().use { resp ->
            if (!resp.isSuccessful) {
                throw RuntimeException("HTTP ${resp.code}")
            }
            post { listener.onOpen() }

            val src = resp.body?.source()
                ?: throw RuntimeException("empty body")
            val reader = src.inputStream().bufferedReader()

            val dataBuf = StringBuilder()
            while (!closed && !Thread.currentThread().isInterrupted) {
                val line = try {
                    reader.readLine()
                } catch (e: Exception) {
                    if (closed) return
                    throw e
                } ?: break   // 流结束

                if (line.isEmpty()) {
                    // 空行 = 事件结束
                    if (dataBuf.isNotEmpty()) {
                        val payload = dataBuf.toString()
                        dataBuf.setLength(0)
                        post { listener.onEvent(payload) }
                    }
                    continue
                }
                if (line.startsWith(":")) {
                    // 注释行 / 心跳，忽略
                    continue
                }
                if (line.startsWith("data:")) {
                    val v = line.substring(5).trim()
                    if (dataBuf.isNotEmpty()) dataBuf.append('\n')
                    dataBuf.append(v)
                }
                // event: / id: / retry: 暂未使用
            }
        }
    }

    private fun post(fn: () -> Unit) {
        mainHandler.post {
            if (!closed) fn()
        }
    }
}