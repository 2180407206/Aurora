package com.Aurora.util

import android.content.Context
import android.util.Base64
import com.google.gson.JsonParser

object TokenManager {
    private const val PREF = "aurora_auth"
    private const val KEY_TOKEN = "token"
    private const val KEY_BASE_URL = "base_url"

    // 模拟器：10.0.2.2 = 宿主机
    // 真机：换成你服务器的 IP:端口，例如 "http://192.168.1.10:8000/"
    const val DEFAULT_BASE_URL = "http://47.113.115.239:8000/"

    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    // ---------------- Token 基础 ----------------

    fun getToken(ctx: Context): String? = sp(ctx).getString(KEY_TOKEN, null)

    fun saveToken(ctx: Context, token: String) {
        sp(ctx).edit().putString(KEY_TOKEN, token).apply()
    }

    fun clear(ctx: Context) {
        sp(ctx).edit().clear().apply()
    }

    fun isLoggedIn(ctx: Context): Boolean = !getToken(ctx).isNullOrBlank()

    // ---------------- BaseUrl ----------------

    fun getBaseUrl(ctx: Context): String =
        sp(ctx).getString(KEY_BASE_URL, null) ?: DEFAULT_BASE_URL

    fun setBaseUrl(ctx: Context, url: String) {
        val n = if (url.endsWith("/")) url else "$url/"
        sp(ctx).edit().putString(KEY_BASE_URL, n).apply()
    }

    // ---------------- JWT 解析 ----------------

    /**
     * 从 JWT payload 里取 sub（userId），失败返回 0。
     * JWT 格式：header.payload.signature，payload 是 Base64URL 编码的 JSON。
     */
    fun getUserId(ctx: Context): Long {
        val payload = decodePayload(ctx) ?: return 0L
        return try {
            val sub = payload.get("sub")?.asString ?: return 0L
            sub.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    /**
     * 从 JWT payload 里取 role，失败返回 "user"。
     */
    fun getRole(ctx: Context): String {
        val payload = decodePayload(ctx) ?: return "user"
        return try {
            payload.get("role")?.asString ?: "user"
        } catch (_: Exception) {
            "user"
        }
    }

    /**
     * 从 JWT payload 里取 username，失败返回 ""。
     */
    fun getUsername(ctx: Context): String {
        val payload = decodePayload(ctx) ?: return ""
        return try {
            payload.get("username")?.asString ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * 解析 JWT 第二段，返回 JsonObject。失败返回 null。
     */
    private fun decodePayload(ctx: Context): com.google.gson.JsonObject? {
        val token = getToken(ctx) ?: return null
        return try {
            val parts = token.split(".")
            if (parts.size < 2) return null
            val raw = Base64.decode(
                parts[1],
                Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
            )
            val json = String(raw, Charsets.UTF_8)
            JsonParser.parseString(json).asJsonObject
        } catch (_: Exception) {
            null
        }
    }
}