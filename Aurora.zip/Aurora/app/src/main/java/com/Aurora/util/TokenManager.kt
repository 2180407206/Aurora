package com.Aurora.util

import android.content.Context

object TokenManager {
    private const val PREF = "aurora_auth"
    private const val KEY_TOKEN = "token"
    private const val KEY_BASE_URL = "base_url"

    // 模拟器：10.0.2.2 = 宿主机
    // 真机：换成你服务器的 IP:端口，例如 "http://192.168.1.10:8000/"
    const val DEFAULT_BASE_URL = "http://47.113.115.239:8000/"

    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun getToken(ctx: Context): String? = sp(ctx).getString(KEY_TOKEN, null)
    fun saveToken(ctx: Context, token: String) {
        sp(ctx).edit().putString(KEY_TOKEN, token).apply()
    }
    fun clear(ctx: Context) { sp(ctx).edit().clear().apply() }
    fun isLoggedIn(ctx: Context): Boolean = !getToken(ctx).isNullOrBlank()

    fun getBaseUrl(ctx: Context): String =
        sp(ctx).getString(KEY_BASE_URL, null) ?: DEFAULT_BASE_URL

    fun setBaseUrl(ctx: Context, url: String) {
        val n = if (url.endsWith("/")) url else "$url/"
        sp(ctx).edit().putString(KEY_BASE_URL, n).apply()
    }
}