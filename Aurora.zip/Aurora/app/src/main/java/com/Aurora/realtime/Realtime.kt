package com.Aurora.realtime

import android.content.Context
import com.Aurora.util.TokenManager
import java.util.concurrent.CopyOnWriteArrayList

/**
 * 全局实时推送枢纽。
 * 三条连接（hall / me / announcements），组件按需订阅。
 *
 * 用法：
 *   // 启动时（MainActivity）
 *   Realtime.start(this)
 *
 *   // 订阅（Fragment/Activity）
 *   val h: (String) -> Unit = { json -> ... }
 *   Realtime.onHall(h)
 *   // onDestroyView
 *   Realtime.offHall(h)
 *
 *   // 退出登录时
 *   Realtime.stop()
 */
object Realtime {

    private var hallClient: SseClient? = null
    private var meClient: SseClient? = null
    private var annClient: SseClient? = null

    private val hallListeners = CopyOnWriteArrayList<(String) -> Unit>()
    private val meListeners = CopyOnWriteArrayList<(String) -> Unit>()
    private val annListeners = CopyOnWriteArrayList<(String) -> Unit>()
    private val stateListeners = CopyOnWriteArrayList<(Boolean) -> Unit>()

    @Volatile private var connected = false

    fun start(ctx: Context) {
        stop()
        val base = TokenManager.getBaseUrl(ctx)
        val token = TokenManager.getToken(ctx)

        // 大厅流：公开
        hallClient = SseClient(
            base + "api/stream/hall",
            token,
            object : SseClient.Listener {
                override fun onOpen() { markConnected(true) }
                override fun onEvent(data: String) {
                    hallListeners.forEach { it(data) }
                }
                override fun onError(t: Throwable?) { markConnected(false) }
            }
        ).also { it.start() }

        // 个人流：需登录
        if (!token.isNullOrBlank()) {
            meClient = SseClient(
                base + "api/stream/me",
                token,
                object : SseClient.Listener {
                    override fun onOpen() {}
                    override fun onEvent(data: String) {
                        meListeners.forEach { it(data) }
                    }
                    override fun onError(t: Throwable?) {}
                }
            ).also { it.start() }
        }

        // 公告流：公开（按角色过滤由服务端做）
        annClient = SseClient(
            base + "api/stream/announcements",
            token,
            object : SseClient.Listener {
                override fun onOpen() {}
                override fun onEvent(data: String) {
                    annListeners.forEach { it(data) }
                }
                override fun onError(t: Throwable?) {}
            }
        ).also { it.start() }
    }

    fun stop() {
        hallClient?.close(); hallClient = null
        meClient?.close();   meClient = null
        annClient?.close();  annClient = null
        connected = false
    }

    // -------- 订阅 --------
    fun onHall(l: (String) -> Unit) { hallListeners.add(l) }
    fun offHall(l: (String) -> Unit) { hallListeners.remove(l) }

    fun onMe(l: (String) -> Unit) { meListeners.add(l) }
    fun offMe(l: (String) -> Unit) { meListeners.remove(l) }

    fun onAnnouncement(l: (String) -> Unit) { annListeners.add(l) }
    fun offAnnouncement(l: (String) -> Unit) { annListeners.remove(l) }

    fun onState(l: (Boolean) -> Unit) { stateListeners.add(l) }
    fun offState(l: (Boolean) -> Unit) { stateListeners.remove(l) }

    fun isConnected() = connected

    private fun markConnected(v: Boolean) {
        if (connected == v) return
        connected = v
        stateListeners.forEach { it(v) }
    }
}