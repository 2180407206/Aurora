package com.Aurora.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.Aurora.MainActivity
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.LoginReq
import com.Aurora.util.ErrUtil
import com.Aurora.util.TokenManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class LoginActivity : AppCompatActivity() {

    // 替代 lifecycleScope，彻底摆脱 KTX 依赖
    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 已登录直接跳主页
        if (TokenManager.isLoggedIn(this)) {
            goMain()
            return
        }

        setContentView(R.layout.activity_login)
        val etU = findViewById<EditText>(R.id.etUsername)
        val etP = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvGo = findViewById<TextView>(R.id.tvGoRegister)
        val tvServer = findViewById<TextView>(R.id.tvServer)

        tvServer.text = "服务器: ${TokenManager.getBaseUrl(this)}"

        // 长按服务器文案可修改地址
        tvServer.setOnLongClickListener {
            val input = EditText(this).apply {
                setText(TokenManager.getBaseUrl(this@LoginActivity))
                hint = "http://192.168.1.10:8000/"
            }
            AlertDialog.Builder(this)
                .setTitle("服务器地址")
                .setView(input)
                .setPositiveButton("保存") { _, _ ->
                    val url = input.text.toString().trim()
                    if (url.isNotEmpty()) {
                        TokenManager.setBaseUrl(this, url)
                        ApiClient.invalidate()
                        tvServer.text = "服务器: ${TokenManager.getBaseUrl(this)}"
                        Toast.makeText(this, "已更新", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("取消", null)
                .show()
            true
        }

        btnLogin.setOnClickListener {
            val u = etU.text.toString().trim()
            val p = etP.text.toString()
            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "请输入账号密码", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            btnLogin.isEnabled = false
            mainScope.launch {
                try {
                    val resp = ApiClient.get(this@LoginActivity).login(LoginReq(u, p))
                    TokenManager.saveToken(this@LoginActivity, resp.accessToken)
                    Toast.makeText(this@LoginActivity, "欢迎，${resp.user.username}", Toast.LENGTH_SHORT).show()
                    goMain()
                } catch (t: Throwable) {
                    Toast.makeText(this@LoginActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                } finally {
                    btnLogin.isEnabled = true
                }
            }
        }

        tvGo.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}