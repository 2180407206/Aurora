package com.Aurora.api

import android.content.Context
import com.Aurora.util.TokenManager
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    private val cache = mutableMapOf<String, ApiService>()

    fun get(ctx: Context): ApiService {
        val base = TokenManager.getBaseUrl(ctx)
        return cache.getOrPut(base) { build(ctx, base) }
    }

    /** 切换服务器地址后调用，清掉旧 client */
    fun invalidate() { cache.clear() }

    private fun build(ctx: Context, baseUrl: String): ApiService {
        val log = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(ctx.applicationContext))
            .addInterceptor(log)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}