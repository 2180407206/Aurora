package com.Aurora.api

import android.content.Context
import com.Aurora.util.TokenManager
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(private val ctx: Context) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = TokenManager.getToken(ctx)
        val req = if (token.isNullOrBlank()) chain.request()
        else chain.request().newBuilder()
            .header("Authorization", "Bearer $token")
            .build()
        return chain.proceed(req)
    }
}