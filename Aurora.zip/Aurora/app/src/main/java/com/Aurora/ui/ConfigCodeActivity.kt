package com.Aurora.ui

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class ConfigCodeActivity : AppCompatActivity() {
    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config_code)

        findViewById<View>(R.id.btnImport).setOnClickListener {
            val code = findViewById<EditText>(R.id.etImportCode).text.toString().trim()
            if (code.isEmpty()) return@setOnClickListener
            mainScope.launch {
                try {
                    val resp = ApiClient.get(this@ConfigCodeActivity).importConfigCode(mapOf("code" to code))
                    Toast.makeText(this@ConfigCodeActivity, "已导入：${resp.payload}", Toast.LENGTH_LONG).show()
                } catch (t: Throwable) {
                    Toast.makeText(this@ConfigCodeActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                }
            }
        }

        loadCodes()
    }

    private fun loadCodes() {
        val ll = findViewById<LinearLayout>(R.id.llCodes)
        mainScope.launch {
            try {
                val list = ApiClient.get(this@ConfigCodeActivity).getSnapshots()
                ll.removeAllViews()
                if (list.isEmpty()) {
                    ll.addView(TextView(this@ConfigCodeActivity).apply {
                        text = "暂无"; setPadding(0, 20, 0, 20); setTextColor(0xFF9AA0A6.toInt())
                    })
                }
                list.forEach { item ->
                    val tv = TextView(this@ConfigCodeActivity).apply {
                        text = "${item.code}  使用 ${item.useCount} 次"
                        setPadding(0, 20, 0, 20); textSize = 16f
                        setTextColor(0xFF1E88E5.toInt())
                        setOnClickListener {
                            findViewById<EditText>(R.id.etImportCode).setText(item.code)
                        }
                    }
                    ll.addView(tv)
                }
            } catch (t: Throwable) {
                Toast.makeText(this@ConfigCodeActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}