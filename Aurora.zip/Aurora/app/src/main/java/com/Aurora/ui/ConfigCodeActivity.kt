package com.Aurora.ui

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class ConfigCodeActivity : AppCompatActivity() {
    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config_code)

        findViewById<View>(R.id.btnImport).setOnClickListener {
            val code = findViewById<EditText>(R.id.etImportCode).text.toString().trim()
            if (code.isEmpty()) return@setOnClickListener
            mainScope.launch {
                try {
                    val r = ApiClient.get(this@ConfigCodeActivity)
                        .let { api ->
                            // 无对应接口，用 okhttp
                            null
                        }
                    // 简化：直接 okhttp
                    val url = com.Aurora.util.TokenManager.getBaseUrl(this@ConfigCodeActivity) + "api/config/import"
                    val json = com.google.gson.Gson().toJson(mapOf("code" to code))
                    val req = okhttp3.Request.Builder().url(url)
                        .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@ConfigCodeActivity) ?: ""))
                        .post(okhttp3.RequestBody.create(json, okhttp3.MediaType.parse("application/json")))
                        .build()
                    val resp = okhttp3.OkHttpClient().newCall(req).execute()
                    val body = resp.body?.string() ?: ""
                    Toast.makeText(this@ConfigCodeActivity, "已导入：$body", Toast.LENGTH_LONG).show()
                } catch (t: Throwable) {
                    Toast.makeText(this@ConfigCodeActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                }
            }
        }

        loadCodes()
    }

    private fun loadCodes() {
        val ll = findViewById<LinearLayout>(R.id.llCodes)
        mainScope.launch {
            try {
                val url = com.Aurora.util.TokenManager.getBaseUrl(this@ConfigCodeActivity) + "api/config/snapshots"
                val req = okhttp3.Request.Builder().url(url)
                    .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@ConfigCodeActivity) ?: ""))
                    .get().build()
                val resp = okhttp3.OkHttpClient().newCall(req).execute()
                val body = resp.body?.string() ?: "[]"
                val arr = com.google.gson.JsonParser.parseString(body).asJsonArray
                ll.removeAllViews()
                if (arr.size() == 0) {
                    ll.addView(TextView(this@ConfigCodeActivity).apply {
                        text = "暂无"; setPadding(0, 20, 0, 20); setTextColor(0xFF9AA0A6.toInt())
                    })
                }
                arr.forEach { el ->
                    val o = el.asJsonObject
                    val tv = TextView(this@ConfigCodeActivity).apply {
                        val code = o.get("code")?.asString ?: "-"
                        val used = o.get("use_count")?.asInt ?: 0
                        text = "$code  使用 $used 次"
                        setPadding(0, 20, 0, 20); textSize = 16f
                        setTextColor(0xFF1E88E5.toInt())
                        setOnClickListener {
                            findViewById<EditText>(R.id.etImportCode).setText(code)
                        }
                    }
                    ll.addView(tv)
                }
            } catch (t: Throwable) {
                Toast.makeText(this@ConfigCodeActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}