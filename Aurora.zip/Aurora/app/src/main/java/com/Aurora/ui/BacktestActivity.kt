package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.BacktestRecordItem
import com.Aurora.model.BacktestResp
import com.Aurora.model.BacktestV2Req
import com.Aurora.util.ErrUtil
import com.Aurora.widget.EquityCurveView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class BacktestActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    private var strategyId: Long = 0L
    private var steps: List<Map<String, Any>> = emptyList()
    private var decision: Map<String, Any> = mapOf("type" to "size", "threshold" to 13)

    private val playTypes = listOf("常规", "倍投", "回本", "追涨")
    private var lastResult: BacktestResp? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backtest)

        strategyId = intent.getLongExtra("strategy_id", 0L)

        // 玩法下拉
        val sp = findViewById<Spinner>(R.id.spPlayType)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, playTypes)

        findViewById<View>(R.id.btnRunBacktest).setOnClickListener { runBacktest() }
        findViewById<View>(R.id.btnSaveRecord).setOnClickListener { saveResult() }
        findViewById<View>(R.id.tvClearHistory).setOnClickListener { confirmClearAll() }

        // 若有 strategy_id，先拉详情把 steps/decision 填进来
        if (strategyId > 0L) {
            loadStrategy()
        } else {
            Toast.makeText(this, "缺少策略 ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        loadHistory()
    }

    // ============================================================
    // 策略加载
    // ============================================================

    private fun loadStrategy() {
        mainScope.launch {
            try {
                val s = ApiClient.get(this@BacktestActivity).strategyDetail(strategyId)
                steps = s.steps ?: emptyList()
                decision = s.decision ?: mapOf("type" to "size", "threshold" to 13)
                title = "回测 - ${s.title}"
            } catch (t: Throwable) {
                Toast.makeText(this@BacktestActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    // ============================================================
    // 运行回测
    // ============================================================

    private fun runBacktest() {
        if (steps.isEmpty()) {
            Toast.makeText(this, "策略还没有步骤，无法回测", Toast.LENGTH_SHORT).show()
            return
        }

        val initBal = findViewById<EditText>(R.id.etInitBalance).text.toString().toDoubleOrNull() ?: 1000.0
        val betAmt = findViewById<EditText>(R.id.etBetAmount).text.toString().toDoubleOrNull() ?: 10.0
        val odds = findViewById<EditText>(R.id.etOdds).text.toString().toDoubleOrNull() ?: 2.0
        val mult = findViewById<EditText>(R.id.etChaseMultiplier).text.toString().toDoubleOrNull() ?: 1.0
        val limit = findViewById<EditText>(R.id.etLimit).text.toString().toIntOrNull() ?: 500
        val playType = (findViewById<Spinner>(R.id.spPlayType).selectedItem as String)

        if (initBal <= 0 || betAmt <= 0) {
            Toast.makeText(this, "初始资金 / 单注金额需 > 0", Toast.LENGTH_SHORT).show()
            return
        }

        val btn = findViewById<View>(R.id.btnRunBacktest)
        btn.isEnabled = false

        mainScope.launch {
            try {
                val req = BacktestV2Req(
                    strategyId = strategyId,
                    steps = steps,
                    decision = decision,
                    playType = playType,
                    limit = limit,
                    initialBalance = initBal,
                    betAmount = betAmt,
                    odds = odds,
                    comboOdds = 2.8,
                    chaseMultiplier = mult,
                    save = false
                )
                val r = ApiClient.get(this@BacktestActivity).backtestV2(req)
                lastResult = r
                renderResult(r, initBal)
                findViewById<View>(R.id.btnSaveRecord).isEnabled = true
            } catch (t: Throwable) {
                Toast.makeText(this@BacktestActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            } finally {
                btn.isEnabled = true
            }
        }
    }

    private fun renderResult(r: BacktestResp, initBal: Double) {
        findViewById<TextView>(R.id.tvWinRate).text = "%.1f%%".format(r.winRate * 100)

        val tvProfit = findViewById<TextView>(R.id.tvProfit)
        tvProfit.text = (if (r.profit >= 0) "+" else "") + "%.2f".format(r.profit)
        tvProfit.setTextColor(if (r.profit >= 0) 0xFF43A047.toInt() else 0xFFE53935.toInt())

        findViewById<TextView>(R.id.tvRoi).text = "%.2f%%".format(r.roi * 100)
        findViewById<TextView>(R.id.tvDrawdown).text = "%.2f%%".format(r.maxDrawdown * 100)
        findViewById<TextView>(R.id.tvBetCount).text = "${r.betCount}"
        findViewById<TextView>(R.id.tvMaxWin).text = "${r.maxWinStreak}"
        findViewById<TextView>(R.id.tvMaxLose).text = "${r.maxLoseStreak}"

        // 曲线
        val curve = findViewById<EquityCurveView>(R.id.curveView)
        curve.setData(r.equityCurve, initBal)

        // 最近成交
        val ll = findViewById<LinearLayout>(R.id.llTrades)
        ll.removeAllViews()
        val trades = r.recentTrades
        if (trades.isEmpty()) {
            ll.addView(hintText("暂无成交"))
        } else {
            trades.reversed().forEach { tr ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(20, 16, 20, 16)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT)
                }
                val t1 = TextView(this).apply {
                    text = "#${tr.nbr}  ${tr.result}"
                    textSize = 13f
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    setTextColor(if (tr.result == "中") 0xFF43A047.toInt() else 0xFFE53935.toInt())
                }
                val t2 = TextView(this).apply {
                    text = "注 %.0f".format(tr.amount)
                    textSize = 13f
                    setTextColor(0xFF5F6368.toInt())
                }
                val t3 = TextView(this).apply {
                    text = (if (tr.profit >= 0) "+" else "") + "%.2f".format(tr.profit)
                    textSize = 13f
                    setPadding(16, 0, 0, 0)
                    setTextColor(if (tr.profit >= 0) 0xFF43A047.toInt() else 0xFFE53935.toInt())
                }
                row.addView(t1); row.addView(t2); row.addView(t3)
                ll.addView(row)
            }
        }
    }

    private fun hintText(msg: String): TextView = TextView(this).apply {
        text = msg
        setPadding(20, 24, 20, 24)
        textSize = 13f
        setTextColor(0xFF9AA0A6.toInt())
    }

    // ============================================================
    // 保存结果（带 save=true 重跑一次，落库）
    // ============================================================

    private fun saveResult() {
        if (lastResult == null) return
        if (steps.isEmpty()) return

        val initBal = findViewById<EditText>(R.id.etInitBalance).text.toString().toDoubleOrNull() ?: 1000.0
        val betAmt = findViewById<EditText>(R.id.etBetAmount).text.toString().toDoubleOrNull() ?: 10.0
        val odds = findViewById<EditText>(R.id.etOdds).text.toString().toDoubleOrNull() ?: 2.0
        val mult = findViewById<EditText>(R.id.etChaseMultiplier).text.toString().toDoubleOrNull() ?: 1.0
        val limit = findViewById<EditText>(R.id.etLimit).text.toString().toIntOrNull() ?: 500
        val playType = (findViewById<Spinner>(R.id.spPlayType).selectedItem as String)

        mainScope.launch {
            try {
                val req = BacktestV2Req(
                    strategyId = strategyId,
                    steps = steps,
                    decision = decision,
                    playType = playType,
                    limit = limit,
                    initialBalance = initBal,
                    betAmount = betAmt,
                    odds = odds,
                    comboOdds = 2.8,
                    chaseMultiplier = mult,
                    save = true
                )
                ApiClient.get(this@BacktestActivity).backtestV2(req)
                Toast.makeText(this@BacktestActivity, "已保存", Toast.LENGTH_SHORT).show()
                loadHistory()
            } catch (t: Throwable) {
                Toast.makeText(this@BacktestActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    // ============================================================
    // 历史记录
    // ============================================================

    private fun loadHistory() {
        mainScope.launch {
            try {
                val r = ApiClient.get(this@BacktestActivity).backtestRecords(20)
                val rv = findViewById<RecyclerView>(R.id.rvRecords)
                rv.layoutManager = LinearLayoutManager(this@BacktestActivity)
                rv.adapter = RecordAdapter(
                    r.items,
                    onDelete = { item -> confirmDelete(item) }
                )
            } catch (_: Throwable) { /* 静默 */ }
        }
    }

    private fun confirmDelete(item: BacktestRecordItem) {
        AlertDialog.Builder(this)
            .setTitle("删除这条记录？")
            .setMessage(item.createdAt)
            .setPositiveButton("删除") { _, _ ->
                mainScope.launch {
                    try {
                        ApiClient.get(this@BacktestActivity).deleteBacktestRecord(item.id)
                        loadHistory()
                    } catch (t: Throwable) {
                        Toast.makeText(this@BacktestActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmClearAll() {
        AlertDialog.Builder(this)
            .setTitle("清空全部历史？")
            .setMessage("将逐条删除你保存过的回测记录")
            .setPositiveButton("清空") { _, _ ->
                mainScope.launch {
                    try {
                        val api = ApiClient.get(this@BacktestActivity)
                        val r = api.backtestRecords(200)
                        r.items.forEach { api.deleteBacktestRecord(it.id) }
                        loadHistory()
                    } catch (t: Throwable) {
                        Toast.makeText(this@BacktestActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}

// ============================================================
// 历史记录 Adapter
// ============================================================

private class RecordAdapter(
    private var data: List<BacktestRecordItem>,
    private val onDelete: (BacktestRecordItem) -> Unit
) : RecyclerView.Adapter<RecordAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTime: TextView = v.findViewById(R.id.tvRecTime)
        val tvMeta: TextView = v.findViewById(R.id.tvRecMeta)
        val tvProfit: TextView = v.findViewById(R.id.tvRecProfit)
        val tvDelete: TextView = v.findViewById(R.id.tvRecDelete)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_backtest_record, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val r = data[pos]
        h.tvTime.text = r.createdAt

        val params = r.params ?: emptyMap()
        val result = r.result ?: emptyMap()
        val init = (params["initial_balance"] as? Number)?.toDouble() ?: 0.0
        val bet = (params["bet_amount"] as? Number)?.toDouble() ?: 0.0
        val lim = (params["limit"] as? Number)?.toInt() ?: 0
        val play = params["play_type"]?.toString() ?: "-"
        h.tvMeta.text = "$play  样本${lim}  初始%.0f  单注%.0f".format(init, bet)

        val profit = (result["profit"] as? Number)?.toDouble() ?: 0.0
        h.tvProfit.text = (if (profit >= 0) "+" else "") + "%.2f".format(profit)
        h.tvProfit.setTextColor(if (profit >= 0) 0xFF43A047.toInt() else 0xFFE53935.toInt())

        h.tvDelete.setOnClickListener { onDelete(r) }
    }

    override fun getItemCount() = data.size
}