package com.Aurora.api

import com.Aurora.model.*
import retrofit2.http.*

interface ApiService {
    // ---- 认证 ----
    @POST("api/auth/register")
    suspend fun register(@Body body: RegisterReq): User

    @POST("api/auth/login")
    suspend fun login(@Body body: LoginReq): TokenResp

    @GET("api/user/me")
    suspend fun me(): User

    // ---- 大厅 ----
    @GET("api/hall/latest")
    suspend fun latest(): HallItem

    @GET("api/hall/history")
    suspend fun history(
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20
    ): HistoryPage

    @GET("api/hall/countdown")
    suspend fun countdown(): CountdownResp

    @GET("api/hall/stats")
    suspend fun hallStats(@Query("limit") limit: Int = 100): HallStats

    // ---- 走势 ----
    @GET("api/trend/dragon")
    suspend fun dragon(@Query("min_len") minLen: Int = 5): DragonResp

    @GET("api/trend/omission")
    suspend fun omission(@Query("limit") limit: Int = 500): OmissionResp

    // ---- 策略 ----
    @GET("api/strategy/hall")
    suspend fun strategyHall(
        @Query("category") category: String = "全部",
        @Query("sort") sort: String = "win_100",
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20,
        @Query("keyword") keyword: String = ""
    ): StrategyPage

    @GET("api/strategy/mine")
    suspend fun myStrategies(
        @Query("scope") scope: String = "created"
    ): List<StrategyItem>

    // ---- 仪表盘 / 钱包 / 日志 / 公告 ----
    @GET("api/dashboard/summary")
    suspend fun dashboard(): DashboardResp

    @GET("api/wallet")
    suspend fun wallet(): Wallet

    @GET("api/betlog")
    suspend fun betlog(
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20
    ): BetLogPage

    @GET("api/announcements")
    suspend fun announcements(): AnnouncementList
}