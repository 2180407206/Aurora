package com.Aurora.api

import com.Aurora.model.*
import retrofit2.http.*

interface ApiService {

    // ---------- 认证 / 用户 ----------
    @POST("api/auth/register")
    suspend fun register(@Body body: RegisterReq): User

    @POST("api/auth/login")
    suspend fun login(@Body body: LoginReq): TokenResp

    @GET("api/user/me")
    suspend fun me(): User

    @PUT("api/user/me/password")
    suspend fun changePassword(@Body body: PasswordChangeReq): SimpleOk

    // ---------- 大厅 ----------
    @GET("api/hall/latest")
    suspend fun latest(): HallItem

    @GET("api/hall/history")
    suspend fun history(
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20
    ): HistoryPage

    @GET("api/hall/history_page")
    suspend fun historyPage(
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20,
        @Query("start_date") startDate: String? = null,
        @Query("end_date") endDate: String? = null,
        @Query("start_nbr") startNbr: Long? = null,
        @Query("end_nbr") endNbr: Long? = null
    ): HistoryPage

    @GET("api/hall/countdown")
    suspend fun countdown(): CountdownResp

    @GET("api/hall/stats")
    suspend fun hallStats(@Query("limit") limit: Int = 100): HallStats

    @GET("api/hall/raw/latest")
    suspend fun rawLatest(): RawKeno

    @GET("api/hall/raw_page")
    suspend fun rawPage(
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20
    ): HistoryRawPage

    @GET("api/hall/raw/{nbr}")
    suspend fun rawByNbr(@Path("nbr") nbr: Long): RawKeno

    // ---------- 走势 ----------
    @GET("api/trend/dragon")
    suspend fun dragon(@Query("min_len") minLen: Int = 5): DragonResp

    @GET("api/trend/omission")
    suspend fun omission(@Query("limit") limit: Int = 500): OmissionResp

    @GET("api/trend/number/{target}")
    suspend fun numberAnalysis(
        @Path("target") target: Int,
        @Query("limit") limit: Int = 500
    ): NumberAnalysis

    // ---------- 策略 ----------
    @GET("api/strategy/hall")
    suspend fun strategyHall(
        @Query("category") category: String = "全部",
        @Query("sort") sort: String = "win_100",
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20,
        @Query("keyword") keyword: String = ""
    ): StrategyPage

    @GET("api/strategy/mine")
    suspend fun myStrategies(
        @Query("scope") scope: String = "created"
    ): List<StrategyItem>

    @GET("api/strategy/{id}")
    suspend fun strategyDetail(@Path("id") id: Long): StrategyItem

    @POST("api/strategy")
    suspend fun createStrategy(@Body body: StrategyCreateReq): StrategyBrief

    @PUT("api/strategy/{id}")
    suspend fun updateStrategy(
        @Path("id") id: Long,
        @Body body: StrategyUpdateReq
    ): StrategyBrief

    @DELETE("api/strategy/{id}")
    suspend fun deleteStrategy(@Path("id") id: Long): StrategyBrief

    @POST("api/strategy/{id}/favorite")
    suspend fun favorite(@Path("id") id: Long): FavoriteResp

    @POST("api/strategy/{id}/submit")
    suspend fun submitReview(@Path("id") id: Long): StrategyBrief

    // ---------- 引擎 ----------
    @GET("api/engine/status")
    suspend fun engineStatus(): EngineStatus

    @GET("api/engine/precheck")
    suspend fun enginePrecheck(): PrecheckResp

    @POST("api/engine/verify_code")
    suspend fun setVerifyCode(@Body body: VerifyCodeReq): SimpleOk

    @POST("api/engine/start")
    suspend fun engineStart(@Body body: EngineStartReq): SimpleOk

    @POST("api/engine/stop")
    suspend fun engineStop(): SimpleOk

    @POST("api/engine/strategies")
    suspend fun upsertEngineStrategy(
        @Body body: Map<String, @JvmSuppressWildcards Any>
    ): SimpleOk

    @DELETE("api/engine/strategies/{sid}")
    suspend fun removeEngineStrategy(@Path("sid") sid: Long): SimpleOk

    // ---------- 钱包 ----------
    @GET("api/wallet")
    suspend fun wallet(): Wallet

    @GET("api/wallet/curve")
    suspend fun walletCurve(@Query("limit") limit: Int = 200): CurveResp

    @GET("api/wallet/stats")
    suspend fun walletStats(): WalletStats

    // ---------- 下注日志 ----------
    @GET("api/betlog")
    suspend fun betlog(
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20,
        @Query("strategy_id") strategyId: Long? = null
    ): BetLogPage

    @GET("api/betlog/summary")
    suspend fun betlogSummary(
        @Query("strategy_id") strategyId: Long? = null
    ): BetLogSummary

    // ---------- 公告 ----------
    @GET("api/announcements")
    suspend fun announcements(@Query("limit") limit: Int = 50): AnnouncementList

    @GET("api/announcements/unread_count")
    suspend fun unreadCount(): Map<String, Any>

    @POST("api/announcements/{id}/read")
    suspend fun markRead(@Path("id") id: Long): SimpleOk

    @POST("api/announcements/read_all")
    suspend fun markAllRead(): Map<String, Any>

    // ---------- 仪表盘 ----------
    @GET("api/dashboard/summary")
    suspend fun dashboard(): DashboardResp

    // ---------- 回测 ----------
    @POST("api/backtest/v2")
    suspend fun backtestV2(@Body body: BacktestV2Req): BacktestResp

    @GET("api/backtest/records")
    suspend fun backtestRecords(@Query("limit") limit: Int = 20): BacktestRecordList

    @DELETE("api/backtest/records/{rid}")
    suspend fun deleteBacktestRecord(@Path("rid") rid: Long): SimpleOk
}

data class HistoryRawPage(
    val total: Int = 0, val page: Int = 1, val size: Int = 20,
    val items: List<RawKeno> = emptyList()
)