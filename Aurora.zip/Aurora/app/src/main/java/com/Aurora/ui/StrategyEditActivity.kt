package com.Aurora.ui

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.*
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class StrategyEditActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    private var editId = 0L
    private val stepInputs = mutableListOf<EditText>()

    private val categories = listOf("大小", "单双", "组合", "杀组", "双组")
    private val directions = listOf("正向", "反向")
    private val decisionTypes = listOf("size", "parity", "combo", "custom")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_strategy_edit)
        editId = intent.getLongExtra("strategy_id", 0L)

        val spCat = findViewById<Spinner>(R.id.spCategory)
        spCat.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        val spDir = findViewById<Spinner>(R.id.spDirection)
        spDir.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, directions)
        val spDec = findViewById<Spinner>(R.id.spDecision)
        spDec.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, decisionTypes)

        findViewById<View>(R.id.btnAddStep).setOnClickListener { addStepInput("") }
        findViewById<View>(R.id.btnSave).setOnClickListener { save() }

        val btnDel = findViewById<View>(R.id.btnDelete)
        if (editId > 0L) {
            btnDel.visibility = View.VISIBLE
            btnDel.setOnClickListener { doDelete() }
            loadExisting()
        } else {
            addStepInput("")
        }
    }

    private fun addStepInput(text: String) {
        val ll = findViewById<LinearLayout>(R.id.llSteps)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val et = EditText(this).apply {
            hint = "公式，如 (a1+b1)%10"
            setText(text)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val del = TextView(this).apply {
            // ✅ 修复 val 重新分配错误，显式使用 this.text 或 setText
            setText("✕")
            setPadding(24, 24, 24, 24); textSize = 18f
            setOnClickListener {
                ll.removeView(row)
                stepInputs.remove(et)
            }
        }
        row.addView(et); row.addView(del)
        ll.addView(row)
        stepInputs.add(et)
    }

    private fun loadExisting() {
        mainScope.launch {
            try {
                val s = ApiClient.get(this@StrategyEditActivity).strategyDetail(editId)
                findViewById<EditText>(R.id.etTitle).setText(s.title)
                findViewById<EditText>(R.id.etNote).setText(s.note ?: "")
                findViewById<Switch>(R.id.swPublic).isChecked = s.isPublic
                (s.steps ?: emptyList()).forEach { st ->
                    addStepInput(st["formula"]?.toString() ?: "")
                }
            } catch (t: Throwable) {
                Toast.makeText(this@StrategyEditActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun save() {
        val title = findViewById<EditText>(R.id.etTitle).text.toString().trim()
        if (title.isEmpty()) {
            Toast.makeText(this, "请填标题", Toast.LENGTH_SHORT).show(); return
        }
        val cat = (findViewById<Spinner>(R.id.spCategory).selectedItem as String)
        val dir = (findViewById<Spinner>(R.id.spDirection).selectedItem as String)
        val dec = (findViewById<Spinner>(R.id.spDecision).selectedItem as String)
        val thr = findViewById<EditText>(R.id.etThreshold).text.toString().toIntOrNull() ?: 13
        val note = findViewById<EditText>(R.id.etNote).text.toString().trim().ifEmpty { null }
        val isPublic = findViewById<Switch>(R.id.swPublic).isChecked

        val steps = stepInputs.mapNotNull {
            it.text.toString().trim().ifEmpty { null }?.let { f -> StepIn(f) }
        }
        if (steps.isEmpty()) {
            Toast.makeText(this, "至少一个步骤", Toast.LENGTH_SHORT).show(); return
        }

        mainScope.launch {
            try {
                val api = ApiClient.get(this@StrategyEditActivity)
                if (editId > 0L) {
                    api.updateStrategy(editId, StrategyUpdateReq(
                        title = title, category = cat, direction = dir,
                        note = note, steps = steps,
                        decision = DecisionIn(dec, thr),
                        isPublic = isPublic))
                } else {
                    api.createStrategy(StrategyCreateReq(
                        title = title, category = cat, direction = dir,
                        note = note, steps = steps,
                        decision = DecisionIn(dec, thr),
                        isPublic = isPublic))
                }
                Toast.makeText(this@StrategyEditActivity, "已保存", Toast.LENGTH_SHORT).show()
                finish()
            } catch (t: Throwable) {
                Toast.makeText(this@StrategyEditActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun doDelete() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("确认删除？").setMessage("删除后无法恢复")
            .setPositiveButton("删除") { _, _ ->
                mainScope.launch {
                    try {
                        ApiClient.get(this@StrategyEditActivity).deleteStrategy(editId)
                        Toast.makeText(this@StrategyEditActivity, "已删除", Toast.LENGTH_SHORT).show()
                        finish()
                    } catch (t: Throwable) {
                        Toast.makeText(this@StrategyEditActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("取消", null).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}