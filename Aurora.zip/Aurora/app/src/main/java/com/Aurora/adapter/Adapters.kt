package com.Aurora.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.model.*

// ============================================================
// 颜色工具
// ============================================================
private fun colorOfSize(size: String?): Int = when (size) {
    "大" -> Color.parseColor("#FB8C00")
    "小" -> Color.parseColor("#1E88E5")
    else -> Color.parseColor("#9AA0A6")
}

private fun colorOfParity(parity: String?): Int = when (parity) {
    "单" -> Color.parseColor("#8E24AA")
    "双" -> Color.parseColor("#00897B")
    else -> Color.parseColor("#9AA0A6")
}

// ============================================================
// 大厅
// ============================================================
class HallAdapter(private var data: List<HallItem>) :
    RecyclerView.Adapter<HallAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvNbr: TextView = v.findViewById(R.id.tvNbr)
        val tvTime: TextView = v.findViewById(R.id.tvTime)
        val tvNum: TextView = v.findViewById(R.id.tvNum)
        val tvCat: TextView = v.findViewById(R.id.tvCat)
        val tvPattern: TextView = v.findViewById(R.id.tvPattern)
        val tvFormula: TextView = v.findViewById(R.id.tvFormula)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_hall, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val it = data[pos]
        h.tvNbr.text = "第 ${it.nbr} 期"
        h.tvTime.text = "${it.date} ${it.time}"
        h.tvNum.text = it.number.toString()
        h.tvNum.setTextColor(colorOfSize(it.size))
        h.tvCat.text = it.category ?: "${it.size ?: ""}${it.parity ?: ""}"
        h.tvCat.setTextColor(colorOfParity(it.parity))
        h.tvFormula.text = "A${it.aTail} + B${it.bTail} + C${it.cTail}"
        if (it.pattern.isNullOrBlank()) {
            h.tvPattern.visibility = View.GONE
        } else {
            h.tvPattern.visibility = View.VISIBLE
            h.tvPattern.text = it.pattern
        }
    }

    override fun getItemCount() = data.size

    fun update(newData: List<HallItem>) {
        data = newData
        notifyDataSetChanged()
    }

    fun append(more: List<HallItem>) {
        val start = data.size
        data = data + more
        notifyItemRangeInserted(start, more.size)
    }

    /** 头插一条（SSE 推来最新一期时用）。同 nbr 去重。 */
    fun insertAtTop(item: HallItem) {
        if (data.any { it.nbr == item.nbr }) return
        data = listOf(item) + data
        notifyItemInserted(0)
    }
}

// ============================================================
// 长龙
// ============================================================
class DragonAdapter(private var data: List<DragonItem>) :
    RecyclerView.Adapter<DragonAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTitle: TextView = v.findViewById(R.id.tvTitle)
        val tvDetail: TextView = v.findViewById(R.id.tvDetail)
        val tvPredict: TextView = v.findViewById(R.id.tvPredict)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_dragon, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val it = data[pos]
        h.tvTitle.text = "${it.type} · ${it.target} 连 ${it.length} 期"
        h.tvDetail.text = "第 ${it.startNbr} → ${it.endNbr} 期"
        h.tvPredict.text = "反转预测：${it.nextPredict ?: "-"}"
    }

    override fun getItemCount() = data.size

    fun update(n: List<DragonItem>) {
        data = n
        notifyDataSetChanged()
    }
}

// ============================================================
// 策略
// ============================================================
class StrategyAdapter(
    private var data: List<StrategyItem>,
    private val onClick: (StrategyItem) -> Unit
) : RecyclerView.Adapter<StrategyAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTitle: TextView = v.findViewById(R.id.tvTitle)
        val tvSub: TextView = v.findViewById(R.id.tvSub)
        val tvStats: TextView = v.findViewById(R.id.tvStats)
        val tvBadge: TextView = v.findViewById(R.id.tvBadge)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_strategy, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val s = data[pos]
        h.tvTitle.text = s.title
        h.tvSub.text = "${s.category} · ${s.direction} · ${s.authorName ?: "匿名"} · ★${s.starCount}"
        val w100 = s.stat?.win100?.let { String.format("100期 %.1f%%", it * 100) } ?: "100期 -"
        val w20 = s.stat?.win20?.let { String.format("20期 %.1f%%", it * 100) } ?: "20期 -"
        h.tvStats.text = "$w20   $w100"
        h.tvBadge.text = when (s.status) {
            "approved" -> "已发布"
            "pending"  -> "待审核"
            "rejected" -> "已驳回"
            else       -> "草稿"
        }
        h.itemView.setOnClickListener { onClick(s) }
    }

    override fun getItemCount() = data.size

    fun update(n: List<StrategyItem>) {
        data = n
        notifyDataSetChanged()
    }
}

// ============================================================
// 下注日志
// ============================================================
class BetLogAdapter(private var data: List<BetLogItem>) :
    RecyclerView.Adapter<BetLogAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvNbr: TextView = v.findViewById(R.id.tvNbr)
        val tvPred: TextView = v.findViewById(R.id.tvPred)
        val tvAmount: TextView = v.findViewById(R.id.tvAmount)
        val tvActual: TextView = v.findViewById(R.id.tvActual)
        val tvWin: TextView = v.findViewById(R.id.tvWin)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_betlog, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val b = data[pos]
        h.tvNbr.text = "#${b.nbr}"
        h.tvPred.text = b.prediction ?: "-"
        h.tvAmount.text = b.amount?.let { "%.0f".format(it) } ?: "-"
        h.tvActual.text = b.actualResult ?: "待开奖"
        when (b.win) {
            true -> {
                h.tvWin.text = "赢"
                h.tvWin.setTextColor(Color.parseColor("#43A047"))
            }
            false -> {
                h.tvWin.text = "输"
                h.tvWin.setTextColor(Color.parseColor("#E53935"))
            }
            else -> {
                h.tvWin.text = "—"
                h.tvWin.setTextColor(Color.parseColor("#9AA0A6"))
            }
        }
    }

    override fun getItemCount() = data.size

    fun update(n: List<BetLogItem>) {
        data = n
        notifyDataSetChanged()
    }
}