package com.Aurora.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.model.DragonItem
import com.Aurora.model.HallItem
import com.Aurora.model.StrategyItem

class HallAdapter(private var data: List<HallItem>) :
    RecyclerView.Adapter<HallAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvNbr: TextView = v.findViewById(R.id.tvNbr)
        val tvTime: TextView = v.findViewById(R.id.tvTime)
        val tvNum: TextView = v.findViewById(R.id.tvNum)
        val tvCat: TextView = v.findViewById(R.id.tvCat)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_hall, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val it = data[pos]
        h.tvNbr.text = "第 ${it.nbr} 期"
        h.tvTime.text = "${it.date} ${it.time}"
        h.tvNum.text = it.number.toString()
        h.tvCat.text = it.category ?: "${it.size ?: ""}${it.parity ?: ""}"
    }

    override fun getItemCount() = data.size

    fun update(newData: List<HallItem>) {
        data = newData
        notifyDataSetChanged()
    }
}

class DragonAdapter(private var data: List<DragonItem>) :
    RecyclerView.Adapter<DragonAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTitle: TextView = v.findViewById(R.id.tvTitle)
        val tvDetail: TextView = v.findViewById(R.id.tvDetail)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_dragon, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val it = data[pos]
        h.tvTitle.text = "${it.type}：${it.target} 连 ${it.length} 期"
        h.tvDetail.text = "预测反转: ${it.nextPredict ?: "-"}  |  第 ${it.startNbr} → ${it.endNbr} 期"
    }

    override fun getItemCount() = data.size

    fun update(n: List<DragonItem>) { data = n; notifyDataSetChanged() }
}

class StrategyAdapter(private var data: List<StrategyItem>) :
    RecyclerView.Adapter<StrategyAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTitle: TextView = v.findViewById(R.id.tvTitle)
        val tvSub: TextView = v.findViewById(R.id.tvSub)
        val tvStats: TextView = v.findViewById(R.id.tvStats)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_strategy, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val s = data[pos]
        h.tvTitle.text = s.title
        h.tvSub.text = "${s.category} · ${s.direction} · by ${s.authorName ?: "匿名"} · 收藏 ${s.starCount}"
        val w100 = s.stat?.win100?.let { String.format("%.1f%%", it * 100) } ?: "-"
        val w20 = s.stat?.win20?.let { String.format("%.1f%%", it * 100) } ?: "-"
        h.tvStats.text = "20期胜率: $w20  |  100期胜率: $w100"
    }

    override fun getItemCount() = data.size

    fun update(n: List<StrategyItem>) { data = n; notifyDataSetChanged() }
}