package com.Aurora.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.adapter.StrategyAdapter
import com.Aurora.api.ApiClient
import com.Aurora.model.StrategyItem
import com.Aurora.util.ErrUtil
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class StrategyFragment : Fragment() {

    private lateinit var adapter: StrategyAdapter
    private var viewScope: CoroutineScope? = null // ✅ 修复：生命周期绑定到视图

    private var scope = "hall"        // hall / mine / favorited / reviewing
    private var category = "全部"
    private var sort = "win_100"
    private var keyword = ""

    private val categories = listOf("全部", "大小", "单双", "组合", "杀组", "双组")
    private val sorts = listOf("胜率100", "胜率20", "热度", "收藏", "最新")
    private val sortKeys = listOf("win_100", "win_20", "hot", "star", "newest")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_strategy, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        
        // ✅ 修复：每次视图创建时，初始化新的协程作用域
        viewScope = CoroutineScope(Dispatchers.Main + Job())

        val rv = v.findViewById<RecyclerView>(R.id.rvStrategy)
        adapter = StrategyAdapter(emptyList()) { item ->
            val i = Intent(requireContext(), StrategyDetailActivity::class.java)
            i.putExtra("strategy_id", item.id)
            startActivity(i)
        }
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        val tab = v.findViewById<TabLayout>(R.id.tabScope)
        listOf("大厅", "我的", "收藏", "待审").forEach { tab.addTab(tab.newTab().setText(it)) }
        tab.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab) {
                scope = when (t.position) {
                    0 -> "hall"; 1 -> "mine"; 2 -> "favorited"; else -> "reviewing"
                }
                load()
            }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) {}
        })

        val llCat = v.findViewById<LinearLayout>(R.id.llCategories)
        categories.forEach { cat ->
            val t = TextView(requireContext())
            t.text = cat
            t.setPadding(28, 12, 28, 12)
            t.textSize = 13f
            t.tag = cat
            t.setOnClickListener { view ->
                category = cat
                updateCategoryStyle(llCat)
                load()
            }
            llCat.addView(t)
        }
        updateCategoryStyle(llCat)

        val sp = v.findViewById<Spinner>(R.id.spSort)
        sp.adapter = ArrayAdapter(requireContext(),
            android.R.layout.simple_spinner_dropdown_item, sorts)
        sp.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) {
                sort = sortKeys[pos]; load()
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }

        val et = v.findViewById<EditText>(R.id.etKeyword)
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                keyword = s?.toString()?.trim() ?: ""
                load()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        v.findViewById<View>(R.id.fabCreate).setOnClickListener {
            startActivity(Intent(requireContext(), StrategyEditActivity::class.java))
        }

        load()
    }

    private fun updateCategoryStyle(ll: LinearLayout) {
        for (i in 0 until ll.childCount) {
            val t = ll.getChildAt(i) as TextView
            val active = t.tag == category
            t.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF5F6368.toInt())
            t.background = if (active)
                android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 40f
                    setColor(0xFF1E88E5.toInt())
                }
            else null
        }
    }

    private fun load() {
        // ✅ 使用 viewScope
        viewScope?.launch {
            try {
                val api = ApiClient.get(requireContext())
                val items: List<StrategyItem> = when (scope) {
                    "hall" -> api.strategyHall(category, sort, 1, 50, keyword).items
                    "mine" -> api.myStrategies("created")
                    "favorited" -> api.myStrategies("favorited")
                    "reviewing" -> api.myStrategies("reviewing")
                    else -> emptyList()
                }
                adapter.update(items)
                if (items.isEmpty()) {
                    Toast.makeText(requireContext(), "暂无策略", Toast.LENGTH_SHORT).show()
                }
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // ✅ 取消 viewScope
        viewScope?.cancel()
        viewScope = null
    }
}