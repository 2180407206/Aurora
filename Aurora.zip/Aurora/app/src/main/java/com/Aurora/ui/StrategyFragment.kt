package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.adapter.StrategyAdapter
import com.Aurora.api.ApiClient
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class StrategyFragment : Fragment() {

    private lateinit var adapter: StrategyAdapter
    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_strategy, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        val rv = v.findViewById<RecyclerView>(R.id.rvStrategy)
        adapter = StrategyAdapter(emptyList())
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        v.findViewById<Button>(R.id.btnRefreshStrategy).setOnClickListener { load() }
        load()
    }

    private fun load() {
        mainScope.launch {
            try {
                val page = ApiClient.get(requireContext())
                    .strategyHall(category = "全部", sort = "win_100", page = 1, size = 30)
                adapter.update(page.items)
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mainScope.cancel()
    }
}