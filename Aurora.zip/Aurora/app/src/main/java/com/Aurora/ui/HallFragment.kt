package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.Aurora.R
import com.Aurora.adapter.HallAdapter
import com.Aurora.api.ApiClient
import com.Aurora.model.HallItem
import com.Aurora.realtime.Realtime
import com.Aurora.util.ErrUtil
import com.google.gson.JsonParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class HallFragment : Fragment() {

    private lateinit var adapter: HallAdapter
    private var viewScope: CoroutineScope? = null // ✅ 修复：每次创建视图时生成
    private var page = 1
    private var loading = false
    private var total = 0

    private var latestNbrInList: Long = 0L

    private val sseHandler: (String) -> Unit = { json ->
        runCatching {
            val obj = JsonParser.parseString(json).asJsonObject
            val type = obj.get("type")?.asString
            if (type == "latest") {
                val nbr = obj.get("nbr")?.asLong ?: 0L
                val number = obj.get("number")?.asInt ?: 0
                val date = obj.get("date")?.asString ?: ""
                val time = obj.get("time")?.asString ?: ""
                val countdown = obj.get("countdown")?.asString ?: ""
                onLatestEvent(nbr, number, date, time, countdown)
            }
        }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_hall, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        
        // ✅ 修复：每次视图创建时，初始化新的协程作用域
        viewScope = CoroutineScope(Dispatchers.Main + Job())

        val swipe = v.findViewById<SwipeRefreshLayout>(R.id.swipe)
        val rv = v.findViewById<RecyclerView>(R.id.rvHistory)
        val pbMore = v.findViewById<View>(R.id.pbMore)

        adapter = HallAdapter(emptyList())
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        swipe.setColorSchemeResources(R.color.brand_primary)
        swipe.setOnRefreshListener {
            page = 1
            load(v, reset = true) { swipe.isRefreshing = false }
        }

        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val lm = rv.layoutManager as LinearLayoutManager
                val lastVisible = lm.findLastVisibleItemPosition()
                if (!loading && adapter.itemCount > 0 && lastVisible >= adapter.itemCount - 3) {
                    if (adapter.itemCount < total) {
                        pbMore.visibility = View.VISIBLE
                        page += 1
                        load(v, reset = false) { pbMore.visibility = View.GONE }
                    }
                }
            }
        })

        load(v, reset = true) {}
        Realtime.onHall(sseHandler)
    }

    private fun onLatestEvent(
        nbr: Long, number: Int,
        date: String, time: String,
        countdown: String
    ) {
        val v = view ?: return
        v.findViewById<TextView>(R.id.tvLatestNbr).text = "第 $nbr 期  ·  $date $time"
        v.findViewById<TextView>(R.id.tvNumber).text = number.toString()
        val size = if (number >= 14) "大" else "小"
        val parity = if (number % 2 == 1) "单" else "双"
        v.findViewById<TextView>(R.id.tvCategory).text = "$size$parity"
        v.findViewById<TextView>(R.id.tvCountdown).text = "下期倒计时 $countdown"

        if (nbr > latestNbrInList) {
            latestNbrInList = nbr
            val newItem = HallItem(
                nbr = nbr, number = number,
                date = date, time = time,
                size = size, parity = parity,
                category = "$size$parity"
            )
            adapter.insertAtTop(newItem)
        }
    }

    private fun load(v: View, reset: Boolean, done: () -> Unit) {
        if (loading) { done(); return }
        loading = true

        val api = ApiClient.get(requireContext())
        // ✅ 使用 viewScope 替代 mainScope
        viewScope?.launch {
            try {
                if (reset) {
                    val latest = api.latest()
                    v.findViewById<TextView>(R.id.tvLatestNbr).text =
                        "第 ${latest.nbr} 期  ·  ${latest.date} ${latest.time}"
                    v.findViewById<TextView>(R.id.tvNumber).text = latest.number.toString()
                    v.findViewById<TextView>(R.id.tvCategory).text = latest.category ?: ""
                    v.findViewById<TextView>(R.id.tvFormula).text =
                        "A${latest.aTail} + B${latest.bTail} + C${latest.cTail}"
                    latestNbrInList = latest.nbr

                    val cd = api.countdown()
                    v.findViewById<TextView>(R.id.tvCountdown).text =
                        "下期倒计时 ${cd.countdown}"

                    val stats = api.hallStats(100)
                    fun p(x: Double) = String.format("%.1f%%", x * 100)
                    v.findViewById<TextView>(R.id.tvBigRatio).text = "大 ${p(stats.bigRatio)}"
                    v.findViewById<TextView>(R.id.tvSmallRatio).text = "小 ${p(stats.smallRatio)}"
                    v.findViewById<TextView>(R.id.tvOddRatio).text = "单 ${p(stats.oddRatio)}"
                    v.findViewById<TextView>(R.id.tvEvenRatio).text = "双 ${p(stats.evenRatio)}"
                }

                val hist = api.historyPage(page = page, size = 20)
                total = hist.total
                if (reset) {
                    adapter.update(hist.items)
                    if (hist.items.isNotEmpty()) {
                        latestNbrInList = maxOf(latestNbrInList, hist.items[0].nbr)
                    }
                } else {
                    adapter.append(hist.items)
                }
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), "加载失败: ${ErrUtil.human(t)}", Toast.LENGTH_SHORT).show()
            } finally {
                loading = false
                done()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Realtime.offHall(sseHandler)
        // ✅ 取消 viewScope 并置空，确保下次切回来重新创建
        viewScope?.cancel()
        viewScope = null
    }
}