package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.adapter.HallAdapter
import com.Aurora.api.ApiClient
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class HallFragment : Fragment() {

    private lateinit var adapter: HallAdapter
    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_hall, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        val rv = v.findViewById<RecyclerView>(R.id.rvHistory)
        adapter = HallAdapter(emptyList())
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        v.findViewById<Button>(R.id.btnRefresh).setOnClickListener { load(v) }
        load(v)
    }

    private fun load(v: View) {
        val tvNbr = v.findViewById<TextView>(R.id.tvLatestNbr)
        val tvNum = v.findViewById<TextView>(R.id.tvNumber)
        val tvCat = v.findViewById<TextView>(R.id.tvCategory)
        val tvFormula = v.findViewById<TextView>(R.id.tvFormula)
        val tvCd = v.findViewById<TextView>(R.id.tvCountdown)
        val tvBig = v.findViewById<TextView>(R.id.tvBigRatio)
        val tvSmall = v.findViewById<TextView>(R.id.tvSmallRatio)
        val tvOdd = v.findViewById<TextView>(R.id.tvOddRatio)
        val tvEven = v.findViewById<TextView>(R.id.tvEvenRatio)

        val api = ApiClient.get(requireContext())
        mainScope.launch {
            try {
                val latest = api.latest()
                tvNbr.text = "第 ${latest.nbr} 期  ·  ${latest.date} ${latest.time}"
                tvNum.text = latest.number.toString()
                tvCat.text = latest.category ?: ""
                tvFormula.text = "${latest.aTail} + ${latest.bTail} + ${latest.cTail}"

                val cd = api.countdown()
                tvCd.text = "下期倒计时 ${cd.countdown}"

                val stats = api.hallStats(100)
                fun p(x: Double) = String.format("%.1f%%", x * 100)
                tvBig.text = "大 ${p(stats.bigRatio)}"
                tvSmall.text = "小 ${p(stats.smallRatio)}"
                tvOdd.text = "单 ${p(stats.oddRatio)}"
                tvEven.text = "双 ${p(stats.evenRatio)}"

                val hist = api.history(1, 30)
                adapter.update(hist.items)
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mainScope.cancel()
    }
}