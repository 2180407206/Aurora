package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.BindCodeReq
import com.Aurora.model.BindPhoneReq
import com.Aurora.model.BindPwdReq
import com.Aurora.model.TgAccount
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class TgActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var adapter: TgAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tg)

        val rv = findViewById<RecyclerView>(R.id.rvTg)
        adapter = TgAdapter(emptyList(), onCheck = { acc -> checkStatus(acc) }, onDelete = { acc -> delete(acc) })
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<View>(R.id.btnAddTg).setOnClickListener { startBind() }
        load()
    }

    private fun load() {
        mainScope.launch {
            try {
                val url = com.Aurora.util.TokenManager.getBaseUrl(this@TgActivity) + "api/tg/accounts"
                val req = okhttp3.Request.Builder().url(url)
                    .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@TgActivity) ?: ""))
                    .get().build()
                val body = okhttp3.OkHttpClient().newCall(req).execute().body?.string() ?: "[]"
                val list = com.google.gson.Gson().fromJson(body, Array<TgAccount>::class.java).toList()
                adapter.update(list)
            } catch (t: Throwable) {
                Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startBind() {
        val et = EditText(this).apply { hint = "手机号 如 +8613800138000" }
        AlertDialog.Builder(this).setTitle("绑定 TG 账号").setView(et)
            .setPositiveButton("发送验证码") { _, _ ->
                val phone = et.text.toString().trim()
                if (phone.isEmpty()) return@setPositiveButton
                mainScope.launch {
                    try {
                        val url = com.Aurora.util.TokenManager.getBaseUrl(this@TgActivity) + "api/tg/0/bind/request_code"
                        val json = com.google.gson.Gson().toJson(mapOf("phone" to phone))
                        val req = okhttp3.Request.Builder().url(url)
                            .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@TgActivity) ?: ""))
                            .post(okhttp3.RequestBody.create(json, okhttp3.MediaType.parse("application/json")))
                            .build()
                        val resp = okhttp3.OkHttpClient().newCall(req).execute()
                        val body = resp.body?.string() ?: ""
                        val o = com.google.gson.JsonParser.parseString(body).asJsonObject
                        val aid = o.get("account_id")?.asLong ?: 0L
                        Toast.makeText(this@TgActivity, "验证码已发送", Toast.LENGTH_SHORT).show()
                        promptCode(aid)
                    } catch (t: Throwable) {
                        Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun promptCode(accountId: Long) {
        val et = EditText(this).apply { hint = "验证码" }
        AlertDialog.Builder(this).setTitle("输入验证码").setView(et)
            .setPositiveButton("提交") { _, _ ->
                val code = et.text.toString().trim()
                mainScope.launch {
                    try {
                        val url = com.Aurora.util.TokenManager.getBaseUrl(this@TgActivity) + "api/tg/$accountId/bind/submit_code"
                        val json = com.google.gson.Gson().toJson(mapOf("code" to code))
                        val req = okhttp3.Request.Builder().url(url)
                            .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@TgActivity) ?: ""))
                            .post(okhttp3.RequestBody.create(json, okhttp3.MediaType.parse("application/json")))
                            .build()
                        val resp = okhttp3.OkHttpClient().newCall(req).execute()
                        val body = resp.body?.string() ?: ""
                        val o = com.google.gson.JsonParser.parseString(body).asJsonObject
                        val need = o.get("need_password")?.asBoolean ?: false
                        if (need) {
                            promptPwd(accountId)
                        } else {
                            Toast.makeText(this@TgActivity, "绑定成功", Toast.LENGTH_SHORT).show()
                            load()
                        }
                    } catch (t: Throwable) {
                        Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun promptPwd(accountId: Long) {
        val et = EditText(this).apply { hint = "两步密码"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("两步验证").setView(et)
            .setPositiveButton("提交") { _, _ ->
                val pwd = et.text.toString()
                mainScope.launch {
                    try {
                        val url = com.Aurora.util.TokenManager.getBaseUrl(this@TgActivity) + "api/tg/$accountId/bind/submit_password"
                        val json = com.google.gson.Gson().toJson(mapOf("password" to pwd))
                        val req = okhttp3.Request.Builder().url(url)
                            .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@TgActivity) ?: ""))
                            .post(okhttp3.RequestBody.create(json, okhttp3.MediaType.parse("application/json")))
                            .build()
                        okhttp3.OkHttpClient().newCall(req).execute().use { }
                        Toast.makeText(this@TgActivity, "绑定成功", Toast.LENGTH_SHORT).show()
                        load()
                    } catch (t: Throwable) {
                        Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun checkStatus(acc: TgAccount) {
        mainScope.launch {
            try {
                val url = com.Aurora.util.TokenManager.getBaseUrl(this@TgActivity) + "api/tg/${acc.id}/status"
                val req = okhttp3.Request.Builder().url(url)
                    .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@TgActivity) ?: ""))
                    .get().build()
                val body = okhttp3.OkHttpClient().newCall(req).execute().body?.string() ?: "{}"
                Toast.makeText(this@TgActivity, body, Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun delete(acc: TgAccount) {
        AlertDialog.Builder(this).setTitle("确认删除？").setMessage(acc.phone)
            .setPositiveButton("删除") { _, _ ->
                mainScope.launch {
                    try {
                        val url = com.Aurora.util.TokenManager.getBaseUrl(this@TgActivity) + "api/tg/accounts/${acc.id}"
                        val req = okhttp3.Request.Builder().url(url)
                            .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@TgActivity) ?: ""))
                            .delete().build()
                        okhttp3.OkHttpClient().newCall(req).execute().use { }
                        load()
                    } catch (t: Throwable) {
                        Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}

class TgAdapter(
    private var data: List<TgAccount>,
    private val onCheck: (TgAccount) -> Unit,
    private val onDelete: (TgAccount) -> Unit
) : RecyclerView.Adapter<TgAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvPhone: TextView = v.findViewById(R.id.tvPhone)
        val tvStatus: TextView = v.findViewById(R.id.tvStatus)
        val tvTgName: TextView = v.findViewById(R.id.tvTgName)
        val btnCheck: View = v.findViewById(R.id.btnCheckStatus)
        val btnDelete: View = v.findViewById(R.id.btnDeleteTg)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_tg_account, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val a = data[pos]
        h.tvPhone.text = a.phone
        h.tvStatus.text = a.status
        h.tvStatus.setTextColor(when (a.status) {
            "bound" -> 0xFF43A047.toInt()
            "pending", "awaiting_code", "awaiting_pwd" -> 0xFFF9A825.toInt()
            else -> 0xFF9AA0A6.toInt()
        })
        h.tvTgName.text = "@${a.tgUsername ?: "-"} · ${a.tgFirstName ?: ""}"
        h.btnCheck.setOnClickListener { onCheck(a) }
        h.btnDelete.setOnClickListener { onDelete(a) }
    }

    override fun getItemCount() = data.size

    fun update(n: List<TgAccount>) { data = n; notifyDataSetChanged() }
}