package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.TgAccount
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class TgActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var adapter: TgAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tg)

        val rv = findViewById<RecyclerView>(R.id.rvTg)
        adapter = TgAdapter(emptyList(), onCheck = { acc -> checkStatus(acc) }, onDelete = { acc -> delete(acc) })
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<View>(R.id.btnAddTg).setOnClickListener { startBind() }
        load()
    }

    private fun load() {
        mainScope.launch {
            try {
                val list = ApiClient.get(this@TgActivity).getTgAccounts()
                adapter.update(list)
            } catch (t: Throwable) {
                Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startBind() {
        val et = EditText(this).apply { hint = "手机号 如 +8613800138000" }
        AlertDialog.Builder(this).setTitle("绑定 TG 账号").setView(et)
            .setPositiveButton("发送验证码") { _, _ ->
                val phone = et.text.toString().trim()
                if (phone.isEmpty()) return@setPositiveButton
                mainScope.launch {
                    try {
                        val resp = ApiClient.get(this@TgActivity)
                            .requestCodeNew(mapOf("phone" to phone))
                        Toast.makeText(this@TgActivity, "验证码已发送", Toast.LENGTH_SHORT).show()
                        resp.accountId?.let { aid -> promptCode(aid) }
                    } catch (t: Throwable) {
                        Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun promptCode(accountId: Long) {
        val et = EditText(this).apply { hint = "验证码" }
        AlertDialog.Builder(this).setTitle("输入验证码").setView(et)
            .setPositiveButton("提交") { _, _ ->
                val code = et.text.toString().trim()
                mainScope.launch {
                    try {
                        val resp = ApiClient.get(this@TgActivity)
                            .submitCode(accountId, mapOf("code" to code))
                        if (resp.needPassword) {
                            promptPwd(accountId)
                        } else {
                            Toast.makeText(this@TgActivity, "绑定成功", Toast.LENGTH_SHORT).show()
                            load()
                        }
                    } catch (t: Throwable) {
                        Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun promptPwd(accountId: Long) {
        val et = EditText(this).apply {
            hint = "两步密码"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("两步验证").setView(et)
            .setPositiveButton("提交") { _, _ ->
                val pwd = et.text.toString()
                mainScope.launch {
                    try {
                        ApiClient.get(this@TgActivity)
                            .submitPassword(accountId, mapOf("password" to pwd))
                        Toast.makeText(this@TgActivity, "绑定成功", Toast.LENGTH_SHORT).show()
                        load()
                    } catch (t: Throwable) {
                        Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun checkStatus(acc: TgAccount) {
        mainScope.launch {
            try {
                val body = ApiClient.get(this@TgActivity).getTgStatus(acc.id)
                Toast.makeText(this@TgActivity, body.toString(), Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun delete(acc: TgAccount) {
        AlertDialog.Builder(this).setTitle("确认删除？").setMessage(acc.phone)
            .setPositiveButton("删除") { _, _ ->
                mainScope.launch {
                    try {
                        ApiClient.get(this@TgActivity).deleteTgAccount(acc.id)
                        load()
                    } catch (t: Throwable) {
                        Toast.makeText(this@TgActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}

class TgAdapter(
    private var data: List<TgAccount>,
    private val onCheck: (TgAccount) -> Unit,
    private val onDelete: (TgAccount) -> Unit
) : RecyclerView.Adapter<TgAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvPhone: TextView = v.findViewById(R.id.tvPhone)
        val tvStatus: TextView = v.findViewById(R.id.tvStatus)
        val tvTgName: TextView = v.findViewById(R.id.tvTgName)
        val btnCheck: View = v.findViewById(R.id.btnCheckStatus)
        val btnDelete: View = v.findViewById(R.id.btnDeleteTg)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_tg_account, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val a = data[pos]
        h.tvPhone.text = a.phone
        h.tvStatus.text = a.status
        h.tvStatus.setTextColor(when (a.status) {
            "bound" -> 0xFF43A047.toInt()
            "pending", "awaiting_code", "awaiting_pwd" -> 0xFFF9A825.toInt()
            else -> 0xFF9AA0A6.toInt()
        })
        h.tvTgName.text = "@${a.tgUsername ?: "-"} · ${a.tgFirstName ?: ""}"
        h.btnCheck.setOnClickListener { onCheck(a) }
        h.btnDelete.setOnClickListener { onDelete(a) }
    }

    override fun getItemCount() = data.size

    fun update(n: List<TgAccount>) { data = n; notifyDataSetChanged() }
}