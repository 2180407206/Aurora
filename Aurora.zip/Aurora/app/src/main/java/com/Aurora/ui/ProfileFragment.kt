package com.Aurora.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.util.ErrUtil
import com.Aurora.util.TokenManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class ProfileFragment : Fragment() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_profile, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)

        val tvUser = v.findViewById<TextView>(R.id.tvUsername)
        val tvRole = v.findViewById<TextView>(R.id.tvRole)
        val tvBal = v.findViewById<TextView>(R.id.tvBalance)
        val tvPnl = v.findViewById<TextView>(R.id.tvProfit)
        val tvBets = v.findViewById<TextView>(R.id.tvTotalBets)
        val tvRate = v.findViewById<TextView>(R.id.tvWinRate)

        v.findViewById<Button>(R.id.btnRefreshProfile).setOnClickListener {
            load(tvUser, tvRole, tvBal, tvPnl, tvBets, tvRate)
        }

        v.findViewById<Button>(R.id.btnLogout).setOnClickListener {
            TokenManager.clear(requireContext())
            val i = Intent(requireContext(), LoginActivity::class.java)
            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(i)
            requireActivity().finish()
        }

        load(tvUser, tvRole, tvBal, tvPnl, tvBets, tvRate)
    }

    private fun load(
        tvUser: TextView, tvRole: TextView,
        tvBal: TextView, tvPnl: TextView,
        tvBets: TextView, tvRate: TextView
    ) {
        mainScope.launch {
            try {
                val api = ApiClient.get(requireContext())
                val me = api.me()
                tvUser.text = me.username
                tvRole.text = "角色: ${me.role}  ·  ${if (me.isActive) "已启用" else "已禁用"}"

                val d = api.dashboard()
                val w = d.wallet
                if (w != null) {
                    tvBal.text = "余额\n${w.currency} ${"%.2f".format(w.currentBalance)}"
                    val p = w.profit
                    tvPnl.text = "盈亏\n${if (p >= 0) "+" else ""}${"%.2f".format(p)}"
                }
                val st = d.stats
                if (st != null) {
                    tvBets.text = "总投注\n${st.totalBets}"
                    tvRate.text = "胜率\n${"%.1f".format(st.winRate * 100)}%"
                }
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mainScope.cancel()
    }
}