package com.Aurora.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.PasswordChangeReq
import com.Aurora.realtime.Realtime
import com.Aurora.util.ErrUtil
import com.Aurora.util.TokenManager
import com.google.gson.JsonParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    // ============================================================
    // SSE：引擎下注战报
    // ============================================================
    private val sseMeHandler: (String) -> Unit = { json ->
        runCatching {
            val obj = JsonParser.parseString(json).asJsonObject
            val type = obj.get("type")?.asString
            if (type == "bet_result") {
                val ok = obj.get("ok")?.asBoolean ?: false
                val nbr = obj.get("nbr")?.asLong ?: 0L
                val pred = obj.get("prediction")?.asString ?: ""
                val title = obj.get("strategy_title")?.asString ?: ""
                val err = obj.get("error")?.asString
                val msg = if (ok) {
                    "第 $nbr 期 · $title · 已下 $pred"
                } else {
                    "第 $nbr 期 · $title · 失败：${err ?: "未知"}"
                }
                Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
                // 顺带刷新钱包/战绩
                view?.let { load(it) }
            }
        }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_profile, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)

        v.findViewById<View>(R.id.rowWallet).setOnClickListener { go(WalletActivity::class.java) }
        v.findViewById<View>(R.id.rowBetlog).setOnClickListener { go(BetLogActivity::class.java) }
        v.findViewById<View>(R.id.rowAnnouncement).setOnClickListener { go(AnnouncementActivity::class.java) }
        v.findViewById<View>(R.id.rowConfig).setOnClickListener { go(ConfigCodeActivity::class.java) }
        v.findViewById<View>(R.id.rowTg).setOnClickListener { go(TgActivity::class.java) }
        v.findViewById<View>(R.id.rowPassword).setOnClickListener { promptChangePwd() }

        v.findViewById<View>(R.id.btnLogout).setOnClickListener {
            // 关键：登出前停掉所有 SSE，避免 me 流 401 无限重试
            Realtime.stop()
            TokenManager.clear(requireContext())

            val i = Intent(requireContext(), LoginActivity::class.java)
            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(i)
            requireActivity().finish()
        }

        // 订阅个人流
        Realtime.onMe(sseMeHandler)

        load(v)
    }

    private fun <T> go(cls: Class<T>) {
        startActivity(Intent(requireContext(), cls))
    }

    private fun load(v: View) {
        mainScope.launch {
            try {
                val api = ApiClient.get(requireContext())
                val me = api.me()
                v.findViewById<TextView>(R.id.tvAvatar).text =
                    me.username.take(1).uppercase()
                v.findViewById<TextView>(R.id.tvUsername).text = me.username
                v.findViewById<TextView>(R.id.tvRole).text =
                    "角色 ${me.role} · ${if (me.isActive) "已启用" else "已禁用"}"

                val d = api.dashboard()
                d.wallet?.let { w ->
                    v.findViewById<TextView>(R.id.tvBalance).text =
                        "${w.currency} %.2f".format(w.currentBalance)
                    val p = w.profit
                    val tvP = v.findViewById<TextView>(R.id.tvProfit)
                    tvP.text = (if (p >= 0) "+" else "") + "%.2f".format(p)
                    tvP.setTextColor(if (p >= 0) 0xFF43A047.toInt() else 0xFFE53935.toInt())
                }
                d.stats?.let { st ->
                    v.findViewById<TextView>(R.id.tvTotalBets).text = "投注 ${st.totalBets}"
                    v.findViewById<TextView>(R.id.tvWinRate).text =
                        "胜率 %.1f%%".format(st.winRate * 100)
                }
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun promptChangePwd() {
        val ll = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 20, 40, 20)
        }
        val etOld = EditText(requireContext()).apply { hint = "原密码" }
        val etNew = EditText(requireContext()).apply { hint = "新密码（≥6位）" }
        ll.addView(etOld)
        ll.addView(etNew)

        AlertDialog.Builder(requireContext())
            .setTitle("修改密码")
            .setView(ll)
            .setPositiveButton("保存") { _, _ ->
                mainScope.launch {
                    try {
                        ApiClient.get(requireContext()).changePassword(
                            PasswordChangeReq(
                                etOld.text.toString(),
                                etNew.text.toString()
                            )
                        )
                        Toast.makeText(requireContext(), "已修改", Toast.LENGTH_SHORT).show()
                    } catch (t: Throwable) {
                        Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Realtime.offMe(sseMeHandler)
        mainScope.cancel()
    }
}