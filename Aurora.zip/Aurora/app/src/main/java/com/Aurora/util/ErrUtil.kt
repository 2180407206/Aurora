package com.Aurora.util

import com.google.gson.JsonParser
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object ErrUtil {
    fun human(t: Throwable): String = when (t) {
        is HttpException -> {
            try {
                val body = t.response()?.errorBody()?.string()
                val obj = JsonParser.parseString(body).asJsonObject
                obj.get("detail")?.asString ?: "HTTP ${t.code()}"
            } catch (_: Exception) { "HTTP ${t.code()}" }
        }
        is ConnectException, is UnknownHostException -> "无法连接服务器"
        is SocketTimeoutException -> "请求超时"
        else -> t.message ?: "未知错误"
    }
}