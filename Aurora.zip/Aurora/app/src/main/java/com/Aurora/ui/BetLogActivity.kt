package com.Aurora.ui

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.adapter.BetLogAdapter
import com.Aurora.api.ApiClient
import com.Aurora.realtime.Realtime
import com.Aurora.util.ErrUtil
import com.google.gson.JsonParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class BetLogActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var adapter: BetLogAdapter

    // ============================================================
    // SSE：新下注结果到达时刷新列表
    // ============================================================
    private val sseMeHandler: (String) -> Unit = { json ->
        runCatching {
            val obj = JsonParser.parseString(json).asJsonObject
            if (obj.get("type")?.asString == "bet_result") {
                reload()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_betlog)

        val rv = findViewById<RecyclerView>(R.id.rvBetlog)
        adapter = BetLogAdapter(emptyList())
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        reload()

        // 订阅个人流
        Realtime.onMe(sseMeHandler)
    }

    private fun reload() {
        mainScope.launch {
            try {
                val api = ApiClient.get(this@BetLogActivity)
                val page = api.betlog(1, 50)
                adapter.update(page.items)

                val s = api.betlogSummary()
                findViewById<TextView>(R.id.tvTotal).text = "总 ${s.total}"
                findViewById<TextView>(R.id.tvWins).text = "中 ${s.wins}"
                findViewById<TextView>(R.id.tvRate).text =
                    "胜率 %.1f%%".format(s.winRate * 100)
            } catch (t: Throwable) {
                Toast.makeText(this@BetLogActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Realtime.offMe(sseMeHandler)
        mainScope.cancel()
    }
}