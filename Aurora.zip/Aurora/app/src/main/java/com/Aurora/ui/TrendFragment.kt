package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.adapter.DragonAdapter
import com.Aurora.api.ApiClient
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class TrendFragment : Fragment() {

    private lateinit var adapter: DragonAdapter
    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_trend, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        val rv = v.findViewById<RecyclerView>(R.id.rvDragon)
        adapter = DragonAdapter(emptyList())
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        v.findViewById<Button>(R.id.btnRefreshTrend).setOnClickListener { load(v) }
        load(v)
    }

    private fun load(v: View) {
        val ll = v.findViewById<LinearLayout>(R.id.llOmission)
        mainScope.launch {
            try {
                val d = ApiClient.get(requireContext()).dragon(5)
                adapter.update(d.items)

                val o = ApiClient.get(requireContext()).omission(500)
                ll.removeAllViews()
                val base = o.data["base"] ?: emptyMap()
                if (base.isEmpty()) {
                    ll.addView(makeRow("无数据", ""))
                } else {
                    base.entries.sortedByDescending { it.value.miss }.forEach { (k, e) ->
                        ll.addView(makeRow(k, "遗漏 ${e.miss} 期  ·  上次 ${e.lastNbr ?: "-"}"))
                    }
                }
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun makeRow(left: String, right: String): View {
        val row = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 16, 0, 16)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val t1 = TextView(requireContext()).apply {
            text = left; textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val t2 = TextView(requireContext()).apply {
            text = right; textSize = 13f
            setTextColor(0xFF666666.toInt())
        }
        row.addView(t1); row.addView(t2)
        return row
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mainScope.cancel()
    }
}