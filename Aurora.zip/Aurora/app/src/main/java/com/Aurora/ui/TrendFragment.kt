package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Aurora.R
import com.Aurora.adapter.DragonAdapter
import com.Aurora.api.ApiClient
import com.Aurora.model.MissEntry
import com.Aurora.util.ErrUtil
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class TrendFragment : Fragment() {

    private lateinit var adapter: DragonAdapter
    private var viewScope: CoroutineScope? = null // ✅ 修复：生命周期绑定到视图

    private val groupLabels = mapOf(
        "base" to "基础", "combo" to "组合", "extreme" to "极值",
        "special" to "特殊", "edge" to "边类", "mod3" to "余3", "mod4" to "余4"
    )
    private val groupOrder = listOf("base", "combo", "extreme", "special", "edge", "mod3", "mod4")

    private var omissionAll: Map<String, Map<String, MissEntry>> = emptyMap()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_trend, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        
        // ✅ 修复：每次视图创建时，初始化新的协程作用域
        viewScope = CoroutineScope(Dispatchers.Main + Job())

        val rv = v.findViewById<RecyclerView>(R.id.rvDragon)
        val tvEmpty = v.findViewById<TextView>(R.id.tvDragonEmpty)
        adapter = DragonAdapter(emptyList())
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter

        val tab = v.findViewById<TabLayout>(R.id.tabOmission)
        groupOrder.forEach { tab.addTab(tab.newTab().setText(groupLabels[it])) }
        tab.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab) { renderOmission(v, groupOrder[t.position]) }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) {}
        })

        v.findViewById<View>(R.id.btnRefreshTrend).setOnClickListener { load(v, tvEmpty) }

        v.findViewById<View>(R.id.btnAnalyze).setOnClickListener {
            val input = v.findViewById<EditText>(R.id.etTargetNumber).text.toString().trim()
            val n = input.toIntOrNull()
            if (n == null || n !in 0..27) {
                Toast.makeText(requireContext(), "请输入 0-27", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            analyze(n)
        }

        load(v, tvEmpty)
    }

    private fun load(v: View, tvEmpty: TextView) {
        // ✅ 使用 viewScope
        viewScope?.launch {
            try {
                val api = ApiClient.get(requireContext())
                val d = api.dragon(5)
                adapter.update(d.items)
                tvEmpty.visibility = if (d.items.isEmpty()) View.VISIBLE else View.GONE

                val o = api.omission(500)
                omissionAll = o.data
                renderOmission(v, "base")
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun renderOmission(v: View, group: String) {
        val ll = v.findViewById<LinearLayout>(R.id.llOmission)
        ll.removeAllViews()
        val map = omissionAll[group] ?: return
        if (map.isEmpty()) {
            ll.addView(makeEmptyRow())
            return
        }
        map.entries.sortedByDescending { it.value.miss }.forEach { (k, e) ->
            ll.addView(makeRow(k, e))
        }
    }

    private fun makeRow(label: String, e: MissEntry): View {
        val row = LayoutInflater.from(requireContext()).inflate(R.layout.item_omission, null)
        row.findViewById<TextView>(R.id.tvLabel).text = label
        row.findViewById<TextView>(R.id.tvMiss).text = "遗漏 ${e.miss} 期"
        row.findViewById<TextView>(R.id.tvLast).text = e.lastNbr?.let { "上次 #$it" } ?: "从未"
        return row
    }

    private fun makeEmptyRow(): View {
        val tv = TextView(requireContext())
        tv.text = "无数据"
        tv.gravity = android.view.Gravity.CENTER
        tv.setPadding(0, 24, 0, 24)
        tv.setTextColor(0xFF9AA0A6.toInt())
        return tv
    }

    private fun analyze(n: Int) {
        // ✅ 使用 viewScope
        viewScope?.launch {
            try {
                val r = ApiClient.get(requireContext()).numberAnalysis(n, 500)
                val d = r.data
                fun s(k: String): String = d[k]?.toString() ?: "-"
                val msg = buildString {
                    append("样本：${s("total_periods")} 期\n")
                    append("出现：${s("hit_count")} 次\n")
                    append("频率：${s("hit_rate")}\n")
                    append("理论：${s("theory_rate")}\n")
                    append("偏差：${s("vs_theory")}%\n")
                    append("平均间隔：${s("avg_interval")}\n")
                    append("最短/最长：${s("min_interval")} / ${s("max_interval")}\n")
                    append("当前遗漏：${s("current_miss")} 期\n")
                    append("自重复：${s("self_repeat")}\n")
                    append("邻号：${s("neighbor_count")} (${s("neighbor_rate")})\n")
                    append("同尾：${s("same_tail_count")} (${s("same_tail_rate")})\n")
                    append("上次：${s("last_time")} (#${s("last_nbr")})")
                }
                AlertDialog.Builder(requireContext())
                    .setTitle("号码 $n 分析")
                    .setMessage(msg)
                    .setPositiveButton("知道了", null)
                    .show()
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // ✅ 取消 viewScope
        viewScope?.cancel()
        viewScope = null
    }
}