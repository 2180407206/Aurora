package com.Aurora.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.*
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class EngineFragment : Fragment() {

    private var viewScope: CoroutineScope? = null // ✅ 修复：生命周期绑定到视图

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_engine, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        
        // ✅ 修复：每次视图创建时，初始化新的协程作用域
        viewScope = CoroutineScope(Dispatchers.Main + Job())

        v.findViewById<View>(R.id.btnRefreshEngine).setOnClickListener { load(v) }
        v.findViewById<View>(R.id.btnSetCode).setOnClickListener { promptSetCode() }
        v.findViewById<View>(R.id.btnStart).setOnClickListener { promptStart() }
        v.findViewById<View>(R.id.btnStop).setOnClickListener { doStop(v) }

        load(v)
    }

    private fun load(v: View) {
        // ✅ 使用 viewScope
        viewScope?.launch {
            try {
                val api = ApiClient.get(requireContext())
                val st = api.engineStatus()
                val pre = api.enginePrecheck()

                v.findViewById<TextView>(R.id.tvEngineState).text =
                    if (st.running) "● 运行中" else "○ 已停止"
                v.findViewById<TextView>(R.id.tvEngineState).setTextColor(
                    if (st.running) 0xFF43A047.toInt() else 0xFF9AA0A6.toInt())
                v.findViewById<TextView>(R.id.tvEngineMeta).text =
                    "账号 ${st.accountId ?: "-"}   主窗口 ${st.primaryWindowId ?: "-"}   启动密码 ${if (st.hasVerifyCode) "已设" else "未设"}"

                val ll = v.findViewById<LinearLayout>(R.id.llPrecheck)
                ll.removeAllViews()
                pre.checks.forEach { c ->
                    val t = TextView(requireContext())
                    t.text = "${if (c.ok) "✓" else "✗"} ${c.label}  ${c.hint}"
                    t.setPadding(24, 20, 24, 20)
                    t.textSize = 14f
                    t.setTextColor(if (c.ok) 0xFF43A047.toInt() else 0xFFE53935.toInt())
                    ll.addView(t)
                }

                val ll2 = v.findViewById<LinearLayout>(R.id.llStrategies)
                ll2.removeAllViews()
                if (st.strategies.isEmpty()) {
                    ll2.addView(hint("尚未挂载策略，请在“策略”页选择后加入引擎"))
                } else {
                    st.strategies.forEach { es ->
                        val t = TextView(requireContext())
                        t.text = "${es.title}   金额 ${es.amount}   ${if (es.enabled) "启用" else "停用"}"
                        t.setPadding(24, 20, 24, 20)
                        t.textSize = 14f
                        ll2.addView(t)
                    }
                }
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun hint(msg: String): TextView = TextView(requireContext()).apply {
        text = msg; setPadding(24, 24, 24, 24); textSize = 13f
        setTextColor(0xFF9AA0A6.toInt())
    }

    private fun promptSetCode() {
        val et = EditText(requireContext()).apply { hint = "至少 4 位" }
        AlertDialog.Builder(requireContext())
            .setTitle("设置启动密码").setView(et)
            .setPositiveButton("保存") { _, _ ->
                val code = et.text.toString().trim()
                if (code.length < 4) return@setPositiveButton
                // ✅ 使用 viewScope
                viewScope?.launch {
                    try {
                        ApiClient.get(requireContext()).setVerifyCode(VerifyCodeReq(code))
                        Toast.makeText(requireContext(), "已设置", Toast.LENGTH_SHORT).show()
                    } catch (t: Throwable) {
                        Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun promptStart() {
        val et = EditText(requireContext()).apply { hint = "输入启动密码" }
        AlertDialog.Builder(requireContext())
            .setTitle("启动引擎").setView(et)
            .setPositiveButton("启动") { _, _ ->
                val code = et.text.toString().trim()
                // ✅ 使用 viewScope
                viewScope?.launch {
                    try {
                        ApiClient.get(requireContext()).engineStart(EngineStartReq(code))
                        Toast.makeText(requireContext(), "已启动", Toast.LENGTH_SHORT).show()
                        view?.let { load(it) }
                    } catch (t: Throwable) {
                        Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun doStop(v: View) {
        // ✅ 使用 viewScope
        viewScope?.launch {
            try {
                ApiClient.get(requireContext()).engineStop()
                Toast.makeText(requireContext(), "已停止", Toast.LENGTH_SHORT).show()
                load(v)
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // ✅ 取消 viewScope
        viewScope?.cancel()
        viewScope = null
    }
}