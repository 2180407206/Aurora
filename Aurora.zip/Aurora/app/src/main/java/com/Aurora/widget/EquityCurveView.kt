package com.Aurora.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.jvm.JvmName // 必须导入这个

/**
 * 资金曲线自绘控件。
 * 输入点：List<Pair<期号, 余额>>，会自动缩放绘制。
 */
class EquityCurveView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var points: List<Pair<Long, Double>> = emptyList()
    private var initBalance = 0.0

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1E88E5.toInt()
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFECEEF1.toInt()
        strokeWidth = 1f
    }
    private val baseLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9AA0A6.toInt()
        strokeWidth = 1f
        style = Paint.Style.STROKE
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 10f), 0f)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9AA0A6.toInt()
        textSize = 24f
    }
    private val path = Path()
    private val fillPath = Path()

    private val padLeft = 60f
    private val padRight = 20f
    private val padTop = 20f
    private val padBottom = 40f

    fun setData(rawCurve: List<Map<String, Any>>, initial: Double) {
        initBalance = initial
        points = rawCurve.mapNotNull { m ->
            val nbr = when (val n = m["nbr"]) {
                is Number -> n.toLong()
                else -> n?.toString()?.toLongOrNull()
            }
            val bal = when (val b = m["balance"]) {
                is Number -> b.toDouble()
                else -> b?.toString()?.toDoubleOrNull()
            }
            if (nbr == null || bal == null) null else nbr to bal
        }
        invalidate()
    }

    // ✅ 修复冲突：添加 @JvmName 告诉编译器在 JVM 里把名字改成 setPairData
    @JvmName("setPairData")
    fun setData(pairs: List<Pair<Long, Double>>, initial: Double) {
        points = pairs
        initBalance = initial
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        val chartL = padLeft
        val chartR = w - padRight
        val chartT = padTop
        val chartB = h - padBottom
        val chartW = chartR - chartL
        val chartH = chartB - chartT

        if (points.isEmpty() || chartW <= 0f || chartH <= 0f) {
            canvas.drawText("暂无数据", w / 2 - 40f, h / 2, textPaint)
            return
        }

        // 计算 y 范围
        val maxV = maxOf(points.maxOf { it.second }, initBalance)
        val minV = minOf(points.minOf { it.second }, initBalance)
        val range = (maxV - minV).takeIf { it > 0.0001 } ?: 1.0
        val pad = range * 0.08
        val yMax = maxV + pad
        val yMin = minV - pad
        val yRange = yMax - yMin

        // 网格（3 条横线）
        for (i in 0..3) {
            val y = chartT + chartH * i / 3f
            canvas.drawLine(chartL, y, chartR, y, gridPaint)
            val v = yMax - yRange * i / 3.0
            canvas.drawText(fmtShort(v), 4f, y + 8f, textPaint)
        }

        // 初始资金基准虚线
        val baseY = chartB - ((initBalance - yMin) / yRange * chartH).toFloat()
        if (baseY in chartT..chartB) {
            canvas.drawLine(chartL, baseY, chartR, baseY, baseLinePaint)
        }

        // 构造曲线
        path.reset()
        fillPath.reset()
        val n = points.size
        val stepX = if (n > 1) chartW / (n - 1) else 0f

        for (i in 0 until n) {
            val x = chartL + stepX * i
            val y = chartB - ((points[i].second - yMin) / yRange * chartH).toFloat()
            if (i == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, chartB)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(chartL + stepX * (n - 1), chartB)
        fillPath.close()

        // 渐变填充
        fillPaint.shader = LinearGradient(
            0f, chartT, 0f, chartB,
            intArrayOf(0x551E88E5, 0x001E88E5),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawPath(fillPath, fillPaint)

        // 曲线
        canvas.drawPath(path, linePaint)

        // X 轴标签：首尾
        canvas.drawText("#${points.first().first}", chartL, h - 12f, textPaint)
        val lastLabel = "#${points.last().first}"
        val lastW = textPaint.measureText(lastLabel)
        canvas.drawText(lastLabel, chartR - lastW, h - 12f, textPaint)
    }

    private fun fmtShort(v: Double): String = when {
        kotlin.math.abs(v) >= 10000 -> "%.1fk".format(v / 1000)
        kotlin.math.abs(v) >= 1000 -> "%.2fk".format(v / 1000)
        else -> "%.0f".format(v)
    }
}