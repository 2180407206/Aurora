package com.Aurora.ui

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.util.ErrUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class WalletActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallet)

        findViewById<View>(R.id.btnSetInit).setOnClickListener { promptSetInit() }
        findViewById<View>(R.id.btnUpdateBalance).setOnClickListener { promptUpdate() }
        load()
    }

    private fun load() {
        mainScope.launch {
            try {
                val api = ApiClient.get(this@WalletActivity)
                val w = api.wallet()
                findViewById<TextView>(R.id.tvCur).text =
                    "${w.currency} %.2f".format(w.currentBalance)
                findViewById<TextView>(R.id.tvInitial).text = "初始 %.0f".format(w.initialBalance)
                findViewById<TextView>(R.id.tvMax).text = "最高 %.0f".format(w.maxBalance)
                findViewById<TextView>(R.id.tvMin).text = "最低 %.0f".format(w.minBalance)

                val ll = findViewById<LinearLayout>(R.id.llCurve)
                ll.removeAllViews()
                val curve = api.walletCurve(100)
                if (curve.items.isEmpty()) {
                    ll.addView(TextView(this@WalletActivity).apply {
                        text = "暂无曲线数据"; setPadding(0, 12, 0, 12)
                        setTextColor(0xFF9AA0A6.toInt())
                    })
                } else {
                    val max = curve.items.maxOf { it.balance }
                    val min = curve.items.minOf { it.balance }
                    curve.items.forEach { p ->
                        val row = LinearLayout(this@WalletActivity).apply {
                            orientation = LinearLayout.HORIZONTAL
                            setPadding(0, 8, 0, 8)
                        }
                        val t1 = TextView(this@WalletActivity).apply {
                            text = p.time; layoutParams =
                                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                            textSize = 12f
                        }
                        val t2 = TextView(this@WalletActivity).apply {
                            text = "%.2f".format(p.balance)
                            textSize = 13f; setTextColor(0xFF1E88E5.toInt())
                        }
                        row.addView(t1); row.addView(t2)
                        ll.addView(row)
                    }
                    ll.addView(TextView(this@WalletActivity).apply {
                        text = "最高 %.2f   最低 %.2f".format(max, min)
                        setPadding(0, 8, 0, 0); textSize = 11f
                        setTextColor(0xFF9AA0A6.toInt())
                    })
                }
            } catch (t: Throwable) {
                Toast.makeText(this@WalletActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun promptSetInit() {
        val et = EditText(this).apply { hint = "初始余额"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        AlertDialog.Builder(this).setTitle("设置初始余额").setView(et)
            .setPositiveButton("保存") { _, _ ->
                val v = et.text.toString().toDoubleOrNull() ?: return@setPositiveButton
                mainScope.launch {
                    try {
                        ApiClient.get(this@WalletActivity).let {
                            // 复用 SetWalletReq schema 需新接口，这里直接打原始接口
                        }
                        // 用 retrofit 直接发 POST api/wallet
                        val body = mapOf("initial_balance" to v, "currency" to "USDT")
                        callSetWallet(body)
                        Toast.makeText(this@WalletActivity, "已设置", Toast.LENGTH_SHORT).show()
                        load()
                    } catch (t: Throwable) {
                        Toast.makeText(this@WalletActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    private fun callSetWallet(body: Map<String, Any>) {
        // 简单用 OkHttp 直发
        val url = com.Aurora.util.TokenManager.getBaseUrl(this) + "api/wallet"
        val json = com.google.gson.Gson().toJson(body)
        val req = okhttp3.Request.Builder().url(url)
            .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this) ?: ""))
            .post(okhttp3.RequestBody.create(json, okhttp3.MediaType.parse("application/json")))
            .build()
        okhttp3.OkHttpClient().newCall(req).execute().use { }
    }

    private fun promptUpdate() {
        val et = EditText(this).apply { hint = "当前余额"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        AlertDialog.Builder(this).setTitle("更新余额").setView(et)
            .setPositiveButton("保存") { _, _ ->
                val v = et.text.toString().toDoubleOrNull() ?: return@setPositiveButton
                mainScope.launch {
                    try {
                        val url = com.Aurora.util.TokenManager.getBaseUrl(this@WalletActivity) + "api/wallet/balance"
                        val json = com.google.gson.Gson().toJson(mapOf("balance" to v))
                        val req = okhttp3.Request.Builder().url(url)
                            .addHeader("Authorization", "Bearer " + (com.Aurora.util.TokenManager.getToken(this@WalletActivity) ?: ""))
                            .post(okhttp3.RequestBody.create(json, okhttp3.MediaType.parse("application/json")))
                            .build()
                        okhttp3.OkHttpClient().newCall(req).execute().use { }
                        Toast.makeText(this@WalletActivity, "已更新", Toast.LENGTH_SHORT).show()
                        load()
                    } catch (t: Throwable) {
                        Toast.makeText(this@WalletActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                    }
                }
            }.setNegativeButton("取消", null).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}