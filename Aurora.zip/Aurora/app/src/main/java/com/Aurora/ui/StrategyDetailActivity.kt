package com.Aurora.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.Aurora.R
import com.Aurora.api.ApiClient
import com.Aurora.model.StrategyItem
import com.Aurora.util.ErrUtil
import com.Aurora.util.TokenManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class StrategyDetailActivity : AppCompatActivity() {

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    private var sid = 0L
    private var loaded: StrategyItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_strategy_detail)

        sid = intent.getLongExtra("strategy_id", 0L)
        if (sid == 0L) {
            finish()
            return
        }

        findViewById<View>(R.id.btnFavorite).setOnClickListener { doFavorite() }
        findViewById<View>(R.id.btnBacktest).setOnClickListener { doBacktest() }
        findViewById<View>(R.id.btnEdit).setOnClickListener {
            val i = Intent(this, StrategyEditActivity::class.java)
            i.putExtra("strategy_id", sid)
            startActivity(i)
        }
        findViewById<View>(R.id.btnSubmit).setOnClickListener { doSubmit() }

        load()
    }

    private fun load() {
        mainScope.launch {
            try {
                val s = ApiClient.get(this@StrategyDetailActivity).strategyDetail(sid)
                loaded = s
                render(s)
            } catch (t: Throwable) {
                Toast.makeText(this@StrategyDetailActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun render(s: StrategyItem) {
        findViewById<TextView>(R.id.tvTitle).text = s.title
        findViewById<TextView>(R.id.tvSub).text =
            "${s.category} · ${s.direction} · ${s.authorName ?: "匿名"} · ★${s.starCount} · 使用 ${s.useCount}"

        val stat = s.stat
        val st = if (stat == null) {
            "暂无统计"
        } else {
            "20期 %.1f%%   100期 %.1f%%   300期 %.1f%%   连续连中 ${stat.currentStreakWin} 连挂 ${stat.currentStreakLose}"
                .format(stat.win20 * 100, stat.win100 * 100, stat.win300 * 100)
        }
        findViewById<TextView>(R.id.tvStats).text = st
        findViewById<TextView>(R.id.tvNote).text = s.note ?: ""

        val ll = findViewById<LinearLayout>(R.id.llSteps)
        ll.removeAllViews()
        val steps = s.steps ?: emptyList()
        if (steps.isEmpty()) {
            val t = TextView(this)
            t.text = "无步骤"
            t.setPadding(0, 8, 0, 8)
            t.setTextColor(0xFF9AA0A6.toInt())
            t.textSize = 14f
            ll.addView(t)
        } else {
            steps.forEachIndexed { idx, step ->
                val t = TextView(this)
                t.text = "第${idx + 1}步:  ${step["formula"] ?: ""}"
                t.setPadding(0, 8, 0, 8)
                t.setTextColor(0xFF1A1A1A.toInt())
                t.textSize = 14f
                ll.addView(t)
            }
        }

        val dec = s.decision
        findViewById<TextView>(R.id.tvDecision).text =
            if (dec == null) "无" else dec.entries.joinToString("  ") { "${it.key}=${it.value}" }

        // 权限：只有自己的策略才能编辑/提交
        val me = TokenManager.getUserId(this)
        val mine = (s.userId != null && s.userId == me)
        findViewById<View>(R.id.btnEdit).visibility = if (mine) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnSubmit).visibility =
            if (mine && s.status in listOf("draft", "rejected")) View.VISIBLE else View.GONE
    }

    private fun doFavorite() {
        mainScope.launch {
            try {
                val r = ApiClient.get(this@StrategyDetailActivity).favorite(sid)
                Toast.makeText(
                    this@StrategyDetailActivity,
                    if (r.favorited) "已收藏" else "已取消",
                    Toast.LENGTH_SHORT
                ).show()
                load()
            } catch (t: Throwable) {
                Toast.makeText(this@StrategyDetailActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun doBacktest() {
        val i = Intent(this, BacktestActivity::class.java)
        i.putExtra("strategy_id", sid)
        startActivity(i)
    }

    private fun doSubmit() {
        mainScope.launch {
            try {
                ApiClient.get(this@StrategyDetailActivity).submitReview(sid)
                Toast.makeText(this@StrategyDetailActivity, "已提交审核", Toast.LENGTH_SHORT).show()
                load()
            } catch (t: Throwable) {
                Toast.makeText(this@StrategyDetailActivity, ErrUtil.human(t), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainScope.cancel()
    }
}