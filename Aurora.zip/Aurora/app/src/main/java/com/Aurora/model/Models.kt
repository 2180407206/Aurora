package com.Aurora.model

import com.google.gson.annotations.SerializedName

// ================= 认证 =================
data class RegisterReq(val username: String, val password: String, val email: String? = null)
data class LoginReq(val username: String, val password: String)

data class User(
    val id: Long,
    val username: String,
    val email: String? = null,
    val role: String = "user",
    @SerializedName("is_active") val isActive: Boolean = true,
    @SerializedName("created_at") val createdAt: String? = null,
    @SerializedName("last_login_at") val lastLoginAt: String? = null
)

data class TokenResp(
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("token_type") val tokenType: String = "bearer",
    val user: User
)

data class PasswordChangeReq(
    @SerializedName("old_password") val oldPassword: String,
    @SerializedName("new_password") val newPassword: String
)

// ================= 大厅 =================
data class HallItem(
    val nbr: Long,
    val number: Int,
    @SerializedName("A_tail") val aTail: Int = 0,
    @SerializedName("B_tail") val bTail: Int = 0,
    @SerializedName("C_tail") val cTail: Int = 0,
    val date: String = "",
    val time: String = "",
    val category: String? = null,
    val size: String? = null,
    val parity: String? = null,
    val pattern: String? = null
)

data class HistoryPage(
    val total: Int = 0, val page: Int = 1, val size: Int = 20,
    val items: List<HallItem> = emptyList()
)

data class CountdownResp(val countdown: String = "00:00")

data class HallStats(
    val total: Int = 0,
    @SerializedName("big_ratio") val bigRatio: Double = 0.0,
    @SerializedName("small_ratio") val smallRatio: Double = 0.0,
    @SerializedName("odd_ratio") val oddRatio: Double = 0.0,
    @SerializedName("even_ratio") val evenRatio: Double = 0.0
)

data class KenoGroup(
    val indices: List<Int> = emptyList(),
    val values: List<Int> = emptyList(),
    val sum: Int = 0,
    val tail: Int = 0
)

data class KenoGroupMeta(
    val label: String = "",
    @SerializedName("indices_text") val indicesText: String = ""
)

data class RawKeno(
    val nbr: Long,
    val date: String = "",
    val time: String = "",
    val nbrs: List<Int> = emptyList(),
    val formula: String = "",
    val number: Int = 0,
    val size: String = "",
    val parity: String = "",
    val category: String = "",
    val pattern: String? = null,
    val groups: Map<String, KenoGroup> = emptyMap(),
    @SerializedName("group_meta") val groupMeta: Map<String, KenoGroupMeta> = emptyMap()
)

// ================= 走势 =================
data class DragonItem(
    val type: String,
    val target: String,
    val length: Int,
    val status: String = "",
    @SerializedName("next_predict") val nextPredict: String? = null,
    @SerializedName("start_nbr") val startNbr: Long = 0,
    @SerializedName("end_nbr") val endNbr: Long = 0,
    val seq: List<String> = emptyList(),
    @SerializedName("start_time") val startTime: String? = null,
    @SerializedName("end_time") val endTime: String? = null
)

data class DragonResp(val ok: Boolean = true, val items: List<DragonItem> = emptyList())

data class MissEntry(
    val miss: Int = 0,
    @SerializedName("last_nbr") val lastNbr: Long? = null,
    @SerializedName("last_time") val lastTime: String? = null
)

data class OmissionResp(
    val ok: Boolean = true,
    val data: Map<String, Map<String, MissEntry>> = emptyMap()
)

data class NumberAnalysis(
    val ok: Boolean = true,
    val data: Map<String, Any> = emptyMap()
)

// ================= 策略 =================
data class StrategyStat(
    @SerializedName("win_20") val win20: Double = 0.0,
    @SerializedName("win_100") val win100: Double = 0.0,
    @SerializedName("win_300") val win300: Double = 0.0,
    @SerializedName("hit_100") val hit100: Int = 0,
    @SerializedName("current_streak_win") val currentStreakWin: Int = 0,
    @SerializedName("current_streak_lose") val currentStreakLose: Int = 0,
    @SerializedName("max_streak_win") val maxStreakWin: Int = 0,
    @SerializedName("max_streak_lose") val maxStreakLose: Int = 0,
    @SerializedName("total_tested") val totalTested: Int = 0
)

data class StrategyItem(
    val id: Long,
    @SerializedName("user_id") val userId: Long? = null,
    val title: String,
    @SerializedName("author_name") val authorName: String? = null,
    val category: String = "",
    val direction: String = "",
    val note: String? = null,
    @SerializedName("is_public") val isPublic: Boolean = false,
    @SerializedName("is_system") val isSystem: Boolean = false,
    @SerializedName("star_count") val starCount: Int = 0,
    @SerializedName("use_count") val useCount: Int = 0,
    val status: String = "",
    @SerializedName("review_note") val reviewNote: String? = null,
    @SerializedName("created_at") val createdAt: String? = null,
    val stat: StrategyStat? = null,
    val steps: List<Map<String, Any>>? = null,
    val decision: Map<String, Any>? = null
)

data class StrategyPage(
    val total: Int = 0, val page: Int = 1, val size: Int = 20,
    val items: List<StrategyItem> = emptyList()
)

data class StrategyBrief(
    val ok: Boolean = true,
    val id: Long? = null,
    val message: String? = null
)

data class StepIn(val formula: String)

data class DecisionIn(
    val type: String = "size",
    val threshold: Int = 13,
    val map: Map<String, String>? = null
)

data class StrategyCreateReq(
    val title: String,
    val category: String = "大小",
    val direction: String = "正向",
    val note: String? = null,
    val steps: List<StepIn> = emptyList(),
    val decision: DecisionIn = DecisionIn(),
    @SerializedName("is_public") val isPublic: Boolean = false
)

data class StrategyUpdateReq(
    val title: String? = null,
    val category: String? = null,
    val direction: String? = null,
    val note: String? = null,
    val steps: List<StepIn>? = null,
    val decision: DecisionIn? = null,
    @SerializedName("is_public") val isPublic: Boolean? = null
)

data class FavoriteResp(
    val ok: Boolean = true,
    val favorited: Boolean = false,
    @SerializedName("star_count") val starCount: Int = 0
)

// ================= 引擎 =================
data class EngineStrategy(
    @SerializedName("strategy_id") val strategyId: Long,
    val title: String = "",
    val enabled: Boolean = false,
    val amount: Int = 0
)

data class EngineStatus(
    val running: Boolean = false,
    @SerializedName("account_id") val accountId: Long? = null,
    @SerializedName("primary_window_id") val primaryWindowId: Long? = null,
    @SerializedName("has_verify_code") val hasVerifyCode: Boolean = false,
    @SerializedName("started_at") val startedAt: String? = null,
    val strategies: List<EngineStrategy> = emptyList()
)

data class PrecheckItem(
    val key: String = "",
    val ok: Boolean = false,
    val label: String = "",
    val hint: String = ""
)

data class PrecheckResp(
    val ok: Boolean = true,
    val ready: Boolean = false,
    val running: Boolean = false,
    val checks: List<PrecheckItem> = emptyList()
)

data class SimpleOk(val ok: Boolean = true, val message: String? = null)
data class VerifyCodeReq(val code: String)
data class EngineStartReq(val code: String)

// ================= 钱包 / 日志 =================
data class Wallet(
    val currency: String = "USDT",
    @SerializedName("initial_balance") val initialBalance: Double = 0.0,
    @SerializedName("current_balance") val currentBalance: Double = 0.0,
    @SerializedName("max_balance") val maxBalance: Double = 0.0,
    @SerializedName("min_balance") val minBalance: Double = 0.0,
    val profit: Double = 0.0,
    @SerializedName("updated_at") val updatedAt: String? = null
)

data class SnapshotPoint(val time: String = "", val balance: Double = 0.0)
data class CurveResp(val ok: Boolean = true, val items: List<SnapshotPoint> = emptyList())

data class WalletStats(
    val ok: Boolean = true,
    @SerializedName("total_bets") val totalBets: Int = 0,
    val wins: Int = 0,
    @SerializedName("win_rate") val winRate: Double = 0.0,
    @SerializedName("win_20") val win20: Double = 0.0,
    @SerializedName("win_50") val win50: Double = 0.0,
    @SerializedName("win_100") val win100: Double = 0.0
)

data class BetLogItem(
    val id: Long,
    val nbr: Long,
    @SerializedName("strategy_id") val strategyId: Long? = null,
    val prediction: String? = null,
    @SerializedName("bet_command") val betCommand: String? = null,
    val amount: Double? = null,
    @SerializedName("actual_number") val actualNumber: Int? = null,
    @SerializedName("actual_result") val actualResult: String? = null,
    val win: Boolean? = null,
    @SerializedName("created_at") val createdAt: String? = null
)

data class BetLogPage(
    val total: Int = 0, val page: Int = 1, val size: Int = 20,
    val items: List<BetLogItem> = emptyList()
)

data class BetLogSummary(
    val total: Int = 0,
    val wins: Int = 0,
    val loses: Int = 0,
    @SerializedName("win_rate") val winRate: Double = 0.0
)

// ================= 公告 =================
data class Announcement(
    val id: Long,
    val title: String,
    val content: String,
    val level: String = "info",
    @SerializedName("target_role") val targetRole: String = "all",
    val pinned: Boolean = false,
    val popup: Boolean = false,
    @SerializedName("publish_at") val publishAt: String? = null,
    @SerializedName("is_read") val isRead: Boolean = false
)

data class AnnouncementList(
    val ok: Boolean = true,
    val total: Int = 0,
    val unread: Int = 0,
    val items: List<Announcement> = emptyList()
)

// ================= 仪表盘 =================
data class DashboardStats(
    @SerializedName("total_bets") val totalBets: Int = 0,
    val wins: Int = 0,
    val loses: Int = 0,
    @SerializedName("win_rate") val winRate: Double = 0.0
)

data class RecentNumber(
    val nbr: Long, val number: Int,
    val date: String = "", val time: String = ""
)

data class EngineBrief(
    val running: Boolean = false,
    @SerializedName("account_id") val accountId: Long? = null,
    @SerializedName("primary_window_id") val primaryWindowId: Long? = null,
    @SerializedName("started_at") val startedAt: String? = null,
    @SerializedName("last_tick_at") val lastTickAt: String? = null
)

data class DashboardResp(
    val ok: Boolean = true,
    val wallet: Wallet? = null,
    val stats: DashboardStats? = null,
    val engine: EngineBrief? = null,
    @SerializedName("unread_announcements") val unreadAnnouncements: Int = 0,
    @SerializedName("recent_numbers") val recentNumbers: List<RecentNumber> = emptyList()
)

// ================= 回测 =================
data class BacktestV2Req(
    @SerializedName("strategy_id") val strategyId: Long? = null,
    val steps: List<Map<String, Any>> = emptyList(),
    val decision: Map<String, Any> = mapOf("type" to "size", "threshold" to 13),
    @SerializedName("play_type") val playType: String = "常规",
    val limit: Int = 500,
    @SerializedName("initial_balance") val initialBalance: Double = 1000.0,
    @SerializedName("bet_amount") val betAmount: Double = 10.0,
    val odds: Double = 2.0,
    @SerializedName("combo_odds") val comboOdds: Double = 2.8,
    @SerializedName("chase_multiplier") val chaseMultiplier: Double = 1.0,
    val save: Boolean = true
)

data class BacktestTrade(
    val nbr: Long = 0,
    val amount: Double = 0.0,
    val level: Int = 0,
    val result: String = "",
    val profit: Double = 0.0,
    val balance: Double = 0.0
)

data class BacktestResp(
    val ok: Boolean = true,
    val total: Int = 0,
    @SerializedName("bet_count") val betCount: Int = 0,
    val wins: Int = 0,
    val loses: Int = 0,
    @SerializedName("win_rate") val winRate: Double = 0.0,
    val profit: Double = 0.0,
    val invest: Double = 0.0,
    val payout: Double = 0.0,
    @SerializedName("final_balance") val finalBalance: Double = 0.0,
    @SerializedName("max_drawdown") val maxDrawdown: Double = 0.0,
    @SerializedName("max_win_streak") val maxWinStreak: Int = 0,
    @SerializedName("max_lose_streak") val maxLoseStreak: Int = 0,
    val roi: Double = 0.0,
    @SerializedName("equity_curve") val equityCurve: List<Map<String, Any>> = emptyList(),
    @SerializedName("recent_trades") val recentTrades: List<BacktestTrade> = emptyList(),
    @SerializedName("record_id") val recordId: Long? = null
)

// ================= 回测记录 =================
data class BacktestRecordItem(
    val id: Long,
    @SerializedName("strategy_id") val strategyId: Long? = null,
    @SerializedName("play_type") val playType: String = "",
    val params: Map<String, Any>? = null,
    val result: Map<String, Any>? = null,
    @SerializedName("created_at") val createdAt: String = ""
)

data class BacktestRecordList(
    val ok: Boolean = true,
    val items: List<BacktestRecordItem> = emptyList()
)

// ================= 配置码 =================
data class SnapshotOut(
    val id: Long,
    val code: String,
    val reused: Boolean = false,
    @SerializedName("use_count") val useCount: Int = 0,
    @SerializedName("size_bytes") val sizeBytes: Int = 0,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("last_used_at") val lastUsedAt: String? = null
)

data class ImportSnapshotResp(
    val ok: Boolean = true,
    val payload: Map<String, Any>? = null,
    @SerializedName("use_count") val useCount: Int = 0,
    val message: String? = null
)

// ================= TG =================
data class TgAccount(
    val id: Long,
    val alias: String? = null,
    val phone: String = "",
    val status: String = "pending",
    @SerializedName("tg_user_id") val tgUserId: Long? = null,
    @SerializedName("tg_username") val tgUsername: String? = null,
    @SerializedName("tg_first_name") val tgFirstName: String? = null,
    @SerializedName("tg_avatar_url") val tgAvatarUrl: String? = null,
    @SerializedName("bound_at") val boundAt: String? = null
)

data class BindPhoneReq(val phone: String)
data class BindCodeReq(val code: String)
data class BindPwdReq(val password: String)

data class BindResp(
    val ok: Boolean = true,
    @SerializedName("account_id") val accountId: Long? = null,
    val msg: String? = null,
    @SerializedName("need_password") val needPassword: Boolean = false
)