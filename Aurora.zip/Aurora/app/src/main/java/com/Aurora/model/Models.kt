package com.Aurora.model

import com.google.gson.annotations.SerializedName

data class RegisterReq(val username: String, val password: String, val email: String?)
data class LoginReq(val username: String, val password: String)

data class User(
    val id: Long,
    val username: String,
    val email: String?,
    val role: String,
    @SerializedName("is_active") val isActive: Boolean = true,
    @SerializedName("created_at") val createdAt: String? = null,
    @SerializedName("last_login_at") val lastLoginAt: String? = null
)

data class TokenResp(
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("token_type") val tokenType: String = "bearer",
    val user: User
)

data class HallItem(
    val nbr: Long,
    val number: Int,
    @SerializedName("A_tail") val aTail: Int = 0,
    @SerializedName("B_tail") val bTail: Int = 0,
    @SerializedName("C_tail") val cTail: Int = 0,
    val date: String = "",
    val time: String = "",
    val category: String? = null,
    val size: String? = null,
    val parity: String? = null,
    val pattern: String? = null
)

data class HistoryPage(
    val total: Int = 0, val page: Int = 1, val size: Int = 20,
    val items: List<HallItem> = emptyList()
)

data class CountdownResp(val countdown: String = "00:00")

data class HallStats(
    val total: Int = 0,
    @SerializedName("big_ratio") val bigRatio: Double = 0.0,
    @SerializedName("small_ratio") val smallRatio: Double = 0.0,
    @SerializedName("odd_ratio") val oddRatio: Double = 0.0,
    @SerializedName("even_ratio") val evenRatio: Double = 0.0
)

data class DragonItem(
    val type: String,
    val target: String,
    val length: Int,
    val status: String = "",
    @SerializedName("next_predict") val nextPredict: String? = null,
    @SerializedName("start_nbr") val startNbr: Long = 0,
    @SerializedName("end_nbr") val endNbr: Long = 0,
    val seq: List<String> = emptyList(),
    @SerializedName("start_time") val startTime: String? = null,
    @SerializedName("end_time") val endTime: String? = null
)

data class DragonResp(val ok: Boolean = true, val items: List<DragonItem> = emptyList())

data class MissEntry(
    val miss: Int = 0,
    @SerializedName("last_nbr") val lastNbr: Long? = null,
    @SerializedName("last_time") val lastTime: String? = null
)

data class OmissionResp(
    val ok: Boolean = true,
    val data: Map<String, Map<String, MissEntry>> = emptyMap()
)

data class StrategyStat(
    @SerializedName("win_20") val win20: Double = 0.0,
    @SerializedName("win_100") val win100: Double = 0.0,
    @SerializedName("win_300") val win300: Double = 0.0,
    @SerializedName("hit_100") val hit100: Int = 0,
    @SerializedName("current_streak_win") val currentStreakWin: Int = 0,
    @SerializedName("current_streak_lose") val currentStreakLose: Int = 0,
    @SerializedName("max_streak_win") val maxStreakWin: Int = 0,
    @SerializedName("max_streak_lose") val maxStreakLose: Int = 0,
    @SerializedName("total_tested") val totalTested: Int = 0
)

data class StrategyItem(
    val id: Long,
    @SerializedName("user_id") val userId: Long? = null,
    val title: String,
    @SerializedName("author_name") val authorName: String? = null,
    val category: String = "",
    val direction: String = "",
    val note: String? = null,
    @SerializedName("is_public") val isPublic: Boolean = false,
    @SerializedName("is_system") val isSystem: Boolean = false,
    @SerializedName("star_count") val starCount: Int = 0,
    @SerializedName("use_count") val useCount: Int = 0,
    val status: String = "",
    @SerializedName("created_at") val createdAt: String? = null,
    val stat: StrategyStat? = null
)

data class StrategyPage(
    val total: Int = 0, val page: Int = 1, val size: Int = 20,
    val items: List<StrategyItem> = emptyList()
)

data class Wallet(
    val currency: String = "USDT",
    @SerializedName("initial_balance") val initialBalance: Double = 0.0,
    @SerializedName("current_balance") val currentBalance: Double = 0.0,
    @SerializedName("max_balance") val maxBalance: Double = 0.0,
    @SerializedName("min_balance") val minBalance: Double = 0.0,
    val profit: Double = 0.0,
    @SerializedName("updated_at") val updatedAt: String? = null
)

data class DashboardStats(
    @SerializedName("total_bets") val totalBets: Int = 0,
    val wins: Int = 0,
    val loses: Int = 0,
    @SerializedName("win_rate") val winRate: Double = 0.0,
    @SerializedName("win_20") val win20: Double = 0.0,
    @SerializedName("win_50") val win50: Double = 0.0,
    @SerializedName("win_100") val win100: Double = 0.0
)

data class RecentNumber(
    val nbr: Long, val number: Int,
    val date: String = "", val time: String = ""
)

data class EngineBrief(
    val running: Boolean = false,
    @SerializedName("account_id") val accountId: Long? = null,
    @SerializedName("primary_window_id") val primaryWindowId: Long? = null,
    @SerializedName("started_at") val startedAt: String? = null,
    @SerializedName("last_tick_at") val lastTickAt: String? = null
)

data class DashboardResp(
    val ok: Boolean = true,
    val wallet: Wallet? = null,
    val stats: DashboardStats? = null,
    val engine: EngineBrief? = null,
    @SerializedName("unread_announcements") val unreadAnnouncements: Int = 0,
    @SerializedName("recent_numbers") val recentNumbers: List<RecentNumber> = emptyList()
)

data class BetLogItem(
    val id: Long,
    val nbr: Long,
    @SerializedName("strategy_id") val strategyId: Long? = null,
    val prediction: String? = null,
    @SerializedName("bet_command") val betCommand: String? = null,
    val amount: Double? = null,
    @SerializedName("actual_result") val actualResult: String? = null,
    val win: Boolean? = null,
    @SerializedName("created_at") val createdAt: String? = null
)

data class BetLogPage(
    val total: Int = 0, val page: Int = 1, val size: Int = 20,
    val items: List<BetLogItem> = emptyList()
)

data class Announcement(
    val id: Long,
    val title: String,
    val content: String,
    val level: String = "info",
    @SerializedName("publish_at") val publishAt: String? = null,
    @SerializedName("is_read") val isRead: Boolean = false
)

data class AnnouncementList(
    val ok: Boolean = true,
    val total: Int = 0,
    val unread: Int = 0,
    val items: List<Announcement> = emptyList()
)