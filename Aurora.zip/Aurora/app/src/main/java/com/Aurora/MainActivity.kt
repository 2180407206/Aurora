package com.Aurora

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.Aurora.api.ApiClient
import com.Aurora.realtime.Realtime
import com.Aurora.ui.*
import com.Aurora.util.TokenManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.gson.JsonParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val hallFrag = HallFragment()
    private val trendFrag = TrendFragment()
    private val strategyFrag = StrategyFragment()
    private val engineFrag = EngineFragment()
    private val profileFrag = ProfileFragment()

    private var current: Fragment = hallFrag
    private val mainScope = CoroutineScope(Dispatchers.Main + Job())

    // 公告未读数（红点）
    private var unreadCount = 0
    private val annHandler: (String) -> Unit = { json ->
        runCatching {
            val obj = JsonParser.parseString(json).asJsonObject
            val type = obj.get("type")?.asString
            if (type == "new" || type == "update" || type == "delete") {
                refreshUnread()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!TokenManager.isLoggedIn(this)) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish(); return
        }

        setContentView(R.layout.activity_main)
        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)

        supportFragmentManager.beginTransaction()
            .replace(R.id.container, hallFrag)
            .commitAllowingStateLoss()

        nav.setOnItemSelectedListener { item ->
            val next = when (item.itemId) {
                R.id.nav_hall     -> hallFrag
                R.id.nav_trend    -> trendFrag
                R.id.nav_strategy -> strategyFrag
                R.id.nav_engine   -> engineFrag
                R.id.nav_profile  -> profileFrag
                else -> return@setOnItemSelectedListener false
            }
            switchTo(next)
            if (item.itemId == R.id.nav_profile) clearUnread()
            true
        }

        // 启动实时推送
        Realtime.start(this)
        Realtime.onAnnouncement(annHandler)

        // 初始拉一次未读数
        refreshUnread()
    }

    override fun onResume() {
        super.onResume()
        // 从后台回前台，重新拉一次未读，防止漏掉断线期间的事件
        if (Realtime.isConnected()) refreshUnread()
    }

    override fun onDestroy() {
        Realtime.offAnnouncement(annHandler)
        // 注意：Realtime.stop() 放在真正退出时。若只想暂停推送可以保留。
        // 这里选择"后台仍保持长连接"，仅在退出登录时 stop。
        mainScope.cancel()
        super.onDestroy()
    }

    private fun switchTo(f: Fragment) {
        if (f === current) return
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .commitAllowingStateLoss()
        current = f
    }

    // ============================================================
    // 公告红点
    // ============================================================

    private fun refreshUnread() {
        mainScope.launch {
            try {
                val r = ApiClient.get(this@MainActivity).unreadCount()
                val n = (r["count"] as? Number)?.toInt()
                    ?: (r["count"] as? String)?.toIntOrNull()
                    ?: 0
                unreadCount = n
                applyBadge(n)
            } catch (_: Throwable) {
                // 静默
            }
        }
    }

    private fun clearUnread() {
        unreadCount = 0
        applyBadge(0)
    }

    private fun applyBadge(n: Int) {
        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)
        if (n > 0) {
            val badge = nav.getOrCreateBadge(R.id.nav_profile)
            badge.isVisible = true
            badge.number = n
            badge.backgroundColor = 0xFFE53935.toInt()
        } else {
            nav.removeBadge(R.id.nav_profile)
        }
    }
}