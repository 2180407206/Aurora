package com.Aurora

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.Aurora.ui.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.Aurora.util.TokenManager

class MainActivity : AppCompatActivity() {

    private val hallFrag = HallFragment()
    private val trendFrag = TrendFragment()
    private val strategyFrag = StrategyFragment()
    private val profileFrag = ProfileFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!TokenManager.isLoggedIn(this)) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish(); return
        }

        setContentView(R.layout.activity_main)
        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)

        switchTo(hallFrag)

        nav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_hall -> switchTo(hallFrag)
                R.id.nav_trend -> switchTo(trendFrag)
                R.id.nav_strategy -> switchTo(strategyFrag)
                R.id.nav_profile -> switchTo(profileFrag)
            }
            true
        }
    }

    private fun switchTo(f: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .commitAllowingStateLoss()
    }
}